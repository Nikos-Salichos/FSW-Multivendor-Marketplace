import axios from 'axios';
import config from '@/config';

let axiosInstance = axios.create({
    baseURL: config.baseURL
});

// headers: {
//     "Content-Type": "multipart/form-data"
//   }

const requestHandler = request => {
    // if (request.url.indexOf('Products/UpdateProductById?productid=') === 0) {
    //     request.headers.common['Content-Type'] = 'multipart/form-data';
    //     request.headers.put['Content-Type'] = 'multipart/form-data';
    // }
    // Products/UpdateProductById?productid=21
    if (typeof localStorage.loginToken !== 'undefined') {
        request.headers.common['Authorization'] = `Bearer ${localStorage.loginToken}`;
    } else {
        delete request.headers.common['Authorization'];
    }
    console.log(request);
    return request;
};

axiosInstance.interceptors.request.use(request => requestHandler(request));

export default axiosInstance;
