<template>
  <v-container fluid>
    <v-radio-group
      v-model="row"
      row
    >
      <v-radio
        label="Personal Account"
        value="radio-1"
      ></v-radio>
      <v-radio
        label="Business Account"
        value="radio-2"
      ></v-radio>
    </v-radio-group>
  </v-container>
</template>


<script>
  export default {
    data () {
      return {
        column: null,
        row: null,
      }
    },
  }
</script>

