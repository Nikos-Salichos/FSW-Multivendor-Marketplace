<template>
    <div class="about">
        <h1>This is an about page</h1>
        <v-btn small color="primary" to="/">Home</v-btn>
    </div>
</template>
<script>
export default {
};
</script>
