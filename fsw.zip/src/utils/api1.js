import axios from 'axios';
import config from '@/config';

var debugMode = true;

let axiosInstance = axios.create({
    baseURL: config.baseURL
});

const requestHandler = request => {
    if (typeof localStorage.loginToken !== 'undefined') {
        request.headers.common['Authorization'] = `Bearer ${localStorage.loginToken}`;
    } else {
        delete request.headers.common['Authorization'];
    }
    if (config.debugMode) {
        var requestData = request.data ? request.data : {};
        console.log(request.method.toUpperCase() + ' ' + request.url, requestData);
    }
    return request;
};

axiosInstance.interceptors.request.use(request => requestHandler(request));

axiosInstance.interceptors.response.use(
    function(response) {
        if (config.debugMode)
            console.log(response.config.method.toUpperCase() + ' ' + response.config.url + ' <- ' + response.status, response.data);
        return response;
    },
    function(error) {
        // if (error.response.status === 401) {
        //     //  store.dispatch('logout')
        //     //  router.push('/login')
        // }
        return Promise.reject(error);
    }
);

export default function(params) {
    return new Promise((resolve, reject) => {
        axiosInstance(params)
            .then(function(response) {
                resolve(response);
            })
            .catch(error => {
                var errorMessage = 'Generic Error';
                if (error.response) {
                    errorMessage = error.response.data;
                } else if (error.request) {
                    //    The request was made but no response was received
                    console.log(error.request);
                } else {
                    //   Something happened in setting up the request that triggered an Error
                    console.log('Error', error.message);
                }
                console.log(error);
                reject(errorMessage);
            });
    });
}
