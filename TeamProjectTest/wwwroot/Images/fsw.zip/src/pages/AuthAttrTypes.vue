<template>
    <v-data-table :headers="headers" :items="rows" sort-by="subCategoryTypeName" class="elevation-1" style="width: 90%"
        >>
        <template v-slot:top>
            <v-toolbar flat>
                <v-toolbar-title>Attributes</v-toolbar-title>
                <v-divider class="mx-4" inset vertical></v-divider>
                <v-spacer></v-spacer>
                <v-dialog v-model="dialog" max-width="70%">
                    <template v-slot:activator="{ on, attrs }">
                        <v-btn color="primary" dark class="mb-2" @click="form()"> New Attribute</v-btn>
                    </template>
                    <v-card>
                        <v-card-title>
                            <span class="headline">{{ formTitle }}</span>
                        </v-card-title>

                        <v-card-text>
                            <v-container>
                                <v-row dense>
                                    <v-col cols="12" sm="6" md="12">
                                        <v-text-field
                                            hide-details
                                            v-model="row.subCategoryTypeName"
                                            label="Attribute"
                                        ></v-text-field>
                                    </v-col>
                                </v-row>
                            </v-container>
                        </v-card-text>

                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn color="blue darken-1" text @click="close"> Cancel </v-btn>
                            <v-btn color="blue darken-1" text @click="save"> Save </v-btn>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
                <v-dialog v-model="dialogDelete" max-width="500px">
                    <v-card>
                        <v-card-title class="headline">Are you sure you want to delete this item?</v-card-title>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn color="blue darken-1" text @click="closeDelete">Cancel</v-btn>
                            <v-btn color="blue darken-1" text @click="deleteItemConfirm">OK</v-btn>
                            <v-spacer></v-spacer>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
            </v-toolbar>
        </template>
        <template v-slot:item.actions="{ item }">
            <!-- v-slot:item.actions="{ item }" -->
            <v-icon small class="mr-2" @click="form(item)"> mdi-pencil </v-icon>
            <v-icon small @click="deleteItem(item)">
                mdi-delete
            </v-icon>
        </template>
    </v-data-table>
</template>
<script>
import { mapFields } from 'vuex-map-fields';

var formMeta = {
    title: 'Attribute'
};

export default {
    data: () => ({
        dialog: false,
        dialogDelete: false,
        editedIndex: -1,
        formMode: '',
        editedItem: {
            subCategoryTypeName: ''
        },
        defaultItem: {
            subCategoryTypeName: ''
        }
    }),

    computed: {
        formTitle() {
            return this.formMode + ' ' + formMeta.title;
            return this.editedIndex === -1 ? 'New Attribute' : 'Edit Attribute';
        },
        ...mapFields('attributes', ['headers', 'rows', 'row'])
    },

    watch: {
        dialog(val) {
            val || this.close();
        },
        dialogDelete(val) {
            val || this.closeDelete();
        }
    },

    mounted() {
        this.$store.dispatch('attributes/rows');
        this.rows = this.$store.getters['attributes/rows'];
    },

    methods: {
        initialize() {},
        form(item) {
            this.formMode = item ? 'Edit' : 'New';
            if (this.formMode == 'Edit') {
                this.row = this.rows.indexOf(item);
                this.row = Object.assign({}, item);
            } else this.row = {};
            this.dialog = true;
        },

        deleteItem(item) {
            // this.editedIndex = this.rows.indexOf(item);
            this.row = Object.assign({}, item);
            this.dialogDelete = true;
        },

        deleteItemConfirm() {
            this.$store.dispatch('attributes/delete', this.row);
            this.closeDelete();
        },

        close() {
            this.dialog = false;
            this.$nextTick(() => {
                this.editedItem = Object.assign({}, this.defaultItem);
                this.editedIndex = -1;
            });
        },

        closeDelete() {
            this.dialogDelete = false;
            this.$nextTick(() => {
                this.editedItem = Object.assign({}, this.defaultItem);
                this.editedIndex = -1;
            });
        },

        save() {
            this.$store.dispatch('attributes/save', this.row);
            this.close();
        }
    }
};
</script>
