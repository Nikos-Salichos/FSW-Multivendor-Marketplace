<template>
    <v-container>
        <v-card>
            <v-card-title>
                <span class="headline">My profile</span>
            </v-card-title>
            <v-row dense>
                <v-col cols="12" sm="6" md="12">
                    <div>Username: {{ row.username }}</div>
                    <br />
                    <div><v-icon medium color="teal darken-2"> mdi-email </v-icon> Email: {{ row.Email }}</div>
                    <br />
                    <div><v-icon medium color="teal darken-2"> mdi-phone </v-icon> Phone: {{ row.Phone }}</div>
                    <br />
                    <div>
                        <v-btn depressed color="primary"> Change Password </v-btn>
                    </div>
                </v-col>
                <v-col cols="12" sm="6" md="12">
                    <br />
                    <v-text-field hide-details v-model="row.Email" label="Email"></v-text-field>
                </v-col>
                <v-col cols="12" sm="6" md="12">
                    <v-text-field hide-details v-model="row.Phone" label="Phone"></v-text-field>
                </v-col>
                <!-- <v-col cols="12" sm="6" md="12">
                    <v-select v-model="role" :items="roles" label="Role" prepend-icon="mdi-account-multiple"></v-select>
                </v-col> -->
            </v-row>
            <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn color="blue darken-1" text @click="close"> Cancel </v-btn>
                <v-btn color="blue darken-1" text @click="save"> Save </v-btn>
            </v-card-actions>
        </v-card>
        <div>
            <v-btn depressed color="primary"> My orders </v-btn>
        </div>
    </v-container>
</template>


<script>
export default {
    data() {
        return {
            row: {
                Phone: '6900000000',
                username: 'Despoina',
                Email: 'example@example.gr',
            },
        };
    },
};
</script>

