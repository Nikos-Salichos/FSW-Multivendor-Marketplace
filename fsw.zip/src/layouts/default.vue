<template>
    <keep-alive>
        <v-app id="inspire">
            <v-navigation-drawer v-model="drawer" :clipped="$vuetify.breakpoint.lgAndUp" app>
                <v-list dense>
                    <v-list-item v-for="item in items" :key="item.title" :to="item.link">
                        <v-list-item-icon>
                            <v-icon>{{ item.icon }}</v-icon>
                        </v-list-item-icon>

                        <v-list-item-content>
                            <v-list-item-title>{{ item.title }}</v-list-item-title>
                        </v-list-item-content>
                    </v-list-item>
                </v-list>
            </v-navigation-drawer>
            <v-app-bar :clipped-left="$vuetify.breakpoint.lgAndUp" app color="primary" dense>
                <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
                <v-toolbar-title>
                    <a href="#/" class="white--text" style="text-decoration: none"> FSW MarketPlace </a>{{ User.role }}
                </v-toolbar-title>
            </v-app-bar>
            <v-main>
                <v-container fluid fill-height>
                    <v-layout justify-center>
                        <router-view />
                    </v-layout>
                </v-container>
            </v-main>
        </v-app>
    </keep-alive>
</template>
<script>
import { mapFields } from 'vuex-map-fields';
var menuItems = {
    Admin: [
        // { title: 'Dashboard', icon: 'mdi-chart-areaspline', link: '/AuthDashboard' },
        { title: 'Orders', icon: 'mdi-cart', link: '/AuthOrders' },
        { title: 'Products', icon: 'mdi-warehouse', link: '/AuthProducts' },
        { title: 'Categories', icon: 'mdi-shape-outline', link: '/AuthCategories' },
        { title: 'Attributes', icon: 'mdi-shape', link: '/AuthAttrTypes' }
    ],
    Vendor: [
        // { title: 'Dashboard', icon: 'mdi-chart-areaspline', link: '/AuthDashboard' },
        // { title: 'Orders', icon: 'mdi-cart', link: '/AuthOrders' },
        { title: 'Products', icon: 'mdi-warehouse', link: '/AuthProducts' }
    ]
};
export default {
    name: 'Navbar',
    data() {
        return {
            drawer: null,
            items: [
                { title: 'Dashboard', icon: 'mdi-chart-areaspline', link: '/AuthDashboard' },
                { title: 'Orders', icon: 'mdi-cart', link: '/AuthOrders' },
                { title: 'Products', icon: 'mdi-warehouse', link: '/AuthProducts' },
                { title: 'Categories', icon: 'mdi-shape-outline', link: '/AuthCategories' },
                { title: 'Attributes', icon: 'mdi-shape', link: '/AuthAttrTypes' },
                { title: 'ResetPassword', icon: 'mdi-information', link: '/ResetPassword' },
                { title: 'Profile', icon: 'mdi-information', link: '/AuthProfile' }
            ]
        };
    },
    computed: {
        ...mapFields(['User'])
    },
    mounted() {
        if (!this.User.role) this.$router.push('/Login');
        else {
            this.items = menuItems[this.User.role];
            // return ;
        }
        // else
    }
};
</script>
<style scoped>
.v-toolbar__title,
.v-btn > .v-btn__content .v-icon {
    color: #fff;
}
</style>
