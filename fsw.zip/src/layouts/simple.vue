<template>
    <v-app>
        <v-main>
            <v-container fluid fill-height>
                <v-progress-linear v-show="progressBar" slot="progress" color="blue" indeterminate />
                <v-layout align-center justify-center>
                    <v-flex xs12 sm8 md4>
                        <router-view />
                    </v-flex>
                </v-layout>
            </v-container>
        </v-main>
    </v-app>
</template>
<script>
export default {
    data: function() {
        return {
            progressBar: false
        };
    }
};
</script>
<style>
#app {
    background: url('../assets/Marketplace.jpg')
        no-repeat center center fixed !important;
    background-size: cover;
    height: 100%;
    overflow: hidden;
}
</style>
