<template>
    <keep-alive>
        <v-app id="inspire">
            <v-navigation-drawer v-model="drawer" :clipped="$vuetify.breakpoint.lgAndUp" app>
                <v-list dense>
                    <v-list-item v-for="item in items" :key="item.title" :to="item.link">
                        <v-list-item-icon>
                            <v-icon>{{ item.icon }}</v-icon>
                        </v-list-item-icon>

                        <v-list-item-content>
                            <v-list-item-title>{{ item.title }}</v-list-item-title>
                        </v-list-item-content>
                    </v-list-item>
                </v-list>
            </v-navigation-drawer>
            <v-app-bar :clipped-left="$vuetify.breakpoint.lgAndUp" app color="primary" dense>
                <v-app-bar-nav-icon @click.stop="drawer = !drawer"></v-app-bar-nav-icon>
                <v-toolbar-title>
                    FSW MarketPlace
                </v-toolbar-title>
            </v-app-bar>
            <v-main>
                <v-container fluid fill-height>
                    <v-layout  justify-center>
                        <router-view />
                    </v-layout>
                </v-container>
            </v-main>
        </v-app>
    </keep-alive>
</template>
<script>
export default {
    name: 'Navbar',
    data() {
        return {
            drawer: null,
            items: [
                { title: 'Home', icon: 'mdi-home', link: '/' },
                { title: 'Dashboard', icon: 'mdi-chart-areaspline', link: '/AuthDashboard' },
                { title: 'Orders', icon: 'mdi-cart', link: '/AuthOrders' },
                { title: 'Products', icon: 'mdi-warehouse', link: '/AuthProducts' },
                { title: 'Categories', icon: 'mdi-shape-outline', link: '/AuthCategories' },
                { title: 'Attributes', icon: 'mdi-shape', link: '/AuthAttrTypes' },
                { title: 'Shop', icon: 'mdi-shape', link: '/Shop' },
                { title: 'Cart', icon: 'mdi-shape', link: '/Cart' },
                { title: 'Login', icon: 'mdi-information', link: '/login' },
                { title: 'Register', icon: 'mdi-information', link: '/Register' },
                { title: 'ResetPassword', icon: 'mdi-information', link: '/ResetPassword' },
                { title: 'Profile', icon: 'mdi-information', link: '/AuthProfile' }
            ]
        };
    }
};
</script>
<style scoped>
.v-toolbar__title,
.v-btn > .v-btn__content .v-icon {
    color: #fff;
}
</style>
