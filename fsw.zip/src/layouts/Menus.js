export default [
    {
        id: 0,
        text: 'Security',
        href: '#',
        children: [
            {
                id: 1,
                text: 'Rights',
                href: 'Rights'
            },
            {
                id: 2,
                text: 'Roles',
                href: 'Roles'
            }
        ]
    },
    {
        id: 3,
        text: 'Persons',
        href: '#',
        children: [
            {
                id: 4,
                text: 'Persons',
                href: 'Persons'
            },
            {
                id: 26,
                text: 'PersonsTaxInfo',
                href: 'PersonsTaxInfo'
            }
        ]
    },
    {
        id: 5,
        text: 'Libraries',
        href: '#',
        children: [
            {
                id: 6,
                text: 'Educations',
                href: 'Educations'
            },
            {
                id: 7,
                text: 'Industries',
                href: 'Industries'
            },
            {
                id: 8,
                text: 'Languages',
                href: 'Languages'
            },
            {
                id: 11,
                text: 'Professions',
                href: 'Professions'
            },
            {
                id: 12,
                text: 'TaxOffice',
                href: 'TaxOffice'
            }
        ]
    },
    {
        id: 9,
        text: 'Geography',
        href: '#',
        children: [
            {
                id: 10,
                text: 'PostalCode',
                href: 'PostalCode'
            },
            {
                id: 20,
                text: 'Cities',
                href: 'Cities'
            },
            {
                id: 21,
                text: 'Countries',
                href: 'Countries'
            },
            {
                id: 22,
                text: 'Prefectures',
                href: 'Prefectures'
            }
        ]
    },
    {
        id: 13,
        text: 'TestCenters',
        href: '#',
        children: [
            {
                id: 14,
                text: 'TestCenters',
                href: 'TestCenters'
            }
        ]
    },
    {
        id: 15,
        text: 'Contracts',
        href: '#',
        children: [
            {
                id: 16,
                text: 'Contracts',
                href: 'Contracts'
            }
        ]
    },
    {
        id: 17,
        text: 'Products',
        href: '#',
        children: [
            {
                id: 18,
                text: 'Assemblies',
                href: 'Assemblies'
            },
            {
                id: 19,
                text: 'ProductFamily',
                href: 'ProductFamily'
            },
            {
                id: 25,
                text: 'Module',
                href: 'Module'
            }
        ]
    },
    {
        id: 23,
        text: 'Certificates',
        href: '#',
        children: [
            {
                id: 24,
                text: 'Certificates',
                href: 'Certificates'
            }
        ]
    },
    {
        id: 27,
        text: 'Common',
        href: '#',
        children: [
            {
                id: 28,
                text: 'ApplicationTasks',
                href: 'ApplicationTasks'
            }
        ]
    }
];
