function index() {
  return import(/* webpackChunkName: "index" */ '@/pages/index.vue')
}
function AuthAttrTypes() {
  return import(
    /* webpackChunkName: "AuthAttrTypes" */ '@/pages/AuthAttrTypes.vue'
  )
}
function AuthCart() {
  return import(/* webpackChunkName: "AuthCart" */ '@/pages/AuthCart.vue')
}
function AuthCategories() {
  return import(
    /* webpackChunkName: "AuthCategories" */ '@/pages/AuthCategories.vue'
  )
}
function AuthCategories_() {
  return import(
    /* webpackChunkName: "AuthCategories_" */ '@/pages/AuthCategories_.vue'
  )
}
function AuthDashboard() {
  return import(
    /* webpackChunkName: "AuthDashboard" */ '@/pages/AuthDashboard.vue'
  )
}
function AuthOrders() {
  return import(/* webpackChunkName: "AuthOrders" */ '@/pages/AuthOrders.vue')
}
function AuthProducts() {
  return import(
    /* webpackChunkName: "AuthProducts" */ '@/pages/AuthProducts.vue'
  )
}
function AuthProfile() {
  return import(/* webpackChunkName: "AuthProfile" */ '@/pages/AuthProfile.vue')
}
function Category() {
  return import(/* webpackChunkName: "Category" */ '@/pages/Category.vue')
}
function Login() {
  return import(/* webpackChunkName: "Login" */ '@/pages/Login.vue')
}
function Product() {
  return import(/* webpackChunkName: "Product" */ '@/pages/Product.vue')
}
function Register() {
  return import(/* webpackChunkName: "Register" */ '@/pages/Register.vue')
}
function ResetPassword() {
  return import(
    /* webpackChunkName: "ResetPassword" */ '@/pages/ResetPassword.vue'
  )
}
function Shop() {
  return import(/* webpackChunkName: "Shop" */ '@/pages/Shop.vue')
}

export default [
  {
    name: 'index',
    path: '',
    component: index,
  },
  {
    name: 'AuthAttrTypes',
    path: 'AuthAttrTypes',
    component: AuthAttrTypes,
  },
  {
    name: 'AuthCart',
    path: 'AuthCart',
    component: AuthCart,
  },
  {
    name: 'AuthCategories',
    path: 'AuthCategories',
    component: AuthCategories,
  },
  {
    name: 'AuthCategories_',
    path: 'AuthCategories_',
    component: AuthCategories_,
  },
  {
    name: 'AuthDashboard',
    path: 'AuthDashboard',
    component: AuthDashboard,
  },
  {
    name: 'AuthOrders',
    path: 'AuthOrders',
    component: AuthOrders,
  },
  {
    name: 'AuthProducts',
    path: 'AuthProducts',
    component: AuthProducts,
  },
  {
    name: 'AuthProfile',
    path: 'AuthProfile',
    component: AuthProfile,
  },
  {
    name: 'Category',
    path: 'Category',
    component: Category,
  },
  {
    name: 'Login',
    path: 'Login',
    component: Login,
  },
  {
    name: 'Product',
    path: 'Product',
    component: Product,
  },
  {
    name: 'Register',
    path: 'Register',
    component: Register,
  },
  {
    name: 'ResetPassword',
    path: 'ResetPassword',
    component: ResetPassword,
  },
  {
    name: 'Shop',
    path: 'Shop',
    component: Shop,
  },
]
