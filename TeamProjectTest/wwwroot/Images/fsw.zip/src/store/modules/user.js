import axios from '@/utils/api';
import api from '@/utils/api1';
import config from '@/config';

var state = {
    authorized: true
};

var getters = {};

var actions = {
    login({ commit }, userData) {
        api({
            method: 'post',
            url: config.api.Login,
            data: {
                username: userData.username,
                password: userData.password
            }
        }).then(function(response) {
            console.log('Login', response.data);
            const token = response.data.token;
            const role = response.data.userRoles[0];
            localStorage.setItem('loginToken', token);
            localStorage.setItem('user', userData.username);
            localStorage.setItem('role', role);
            axios.defaults.headers.common['Authorization'] = 'Bearer ' + token;
            commit('login');
        });
    },
    resetPassword({ commit }, userData) {
        api({
            method: 'post',
            url: config.api.Login,
            data: {
                username: userData.username,
                password: userData.password
            }
        }).then(function(response) {
            console.log('resetPassword', response.data);
            const token = response.data.token;
            const role = response.data.userRoles[0];
            localStorage.setItem('loginToken', token);
            localStorage.setItem('user', userData.username);
            localStorage.setItem('role', role);
            axios.defaults.headers.common['Authorization'] = 'Bearer ' + token;
            commit('login');
        });
    },
    changePassword({ commit }, userData) {
        return api({
            method: 'post',
            url: config.api.ChangePassword,
            data: {
                currentPassword: userData.currentPassword,
                newPassword: userData.newPassword,
                confirmPassword: userData.confirmPassword
            }
        });
    },
    register({ commit }, userData) {
        return api({
            method: 'post',
            url: config.api[userData.role + 'Register'],
            data: {
                username: userData.username,
                email: userData.email,
                password: userData.password
            }
        });
    }
};
var mutations = {
    login(state) {
        state.authorized = true;
    }
};

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
};
