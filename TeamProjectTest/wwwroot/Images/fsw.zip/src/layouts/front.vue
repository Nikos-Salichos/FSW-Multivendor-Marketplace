<template>
    <v-app id="inspire">
        <v-app-bar :clipped-left="$vuetify.breakpoint.lgAndUp" app color="primary" dark>
            <!--      <v-app-bar-nav-icon @click.stop="drawer = !drawer" />-->

            <v-toolbar-title style="width: 350px">
                <a href="#/" class="white--text" style="text-decoration: none"><v-icon>mdi-truck</v-icon>&nbsp;FSW Marketplace</a>
            </v-toolbar-title>
            <!-- <v-text-field
                flat
                solo-inverted
                hide-details
                prepend-inner-icon="mdi-magnify"
                label="Search"
                class="hidden-sm-and-down pl-10 ml-4"
            /> -->
            <v-autocomplete
                prepend-inner-icon="mdi-magnify"
                v-model="select"
                :loading="loading"
                :items="items"
                :search-input.sync="search"
                cache-items
                class="mx-4"
                flat
                hide-no-data
                hide-details
                label="Search"
                solo-inverted
                @change="selectProduct"
                item-text="productName"
                item-value="productId"
            ></v-autocomplete>
            <v-spacer />
            <v-menu bottom left>
                <template v-slot:activator="{ on, attrs }">
                    <v-btn dark icon v-bind="attrs" v-on="on">
                        <v-icon>mdi-account-circle</v-icon>
                    </v-btn>
                </template>

                <v-list dense>
                    <v-list-item>
                        <v-list-item-title><a>Change Password</a></v-list-item-title>
                    </v-list-item>
                    <v-list-item>
                        <v-list-item-title><a>Logout</a></v-list-item-title>
                    </v-list-item>
                </v-list>
            </v-menu>
            <!-- <v-btn icon>
                <v-badge content="2" value="2" color="green" overlap>
                    <v-icon>mdi-bell</v-icon>
                </v-badge>
            </v-btn> -->
            <router-link to="Cart">
                <v-icon>mdi-cart</v-icon>
                <!-- <v-badge content="2" value="2" color="green" overlap>
                    <v-icon>mdi-cart</v-icon>
                </v-badge> -->
            </router-link>
        </v-app-bar>
        <v-main>
            <v-bottom-navigation :value="activeBtn" color="primary" horizontal>
                <a href="#/Shop" class="v-btn">
                    <span>Home</span>
                </a>
                <v-menu open-on-hover offset-y>
                    <template v-slot:activator="{ on }">
                        <v-btn v-on="on">
                            <span>Shop</span>
                        </v-btn>
                    </template>
                    <v-card class="mx-auto" max-width="344" outlined>
                        <v-list-item
                            v-for="(Category, index) in Categories"
                            :key="index"
                            @click=""
                            :to="{ name: 'Category', params: { id: Category.categoryId, name: Category.categoryName } }"
                        >
                            <v-list-item-title>{{ Category.categoryName }}</v-list-item-title>
                        </v-list-item>
                    </v-card>
                </v-menu>
                <!-- <a href="/product" class="v-btn">
                    <span>Product</span>
                </a>
                <v-btn href="/blog">
                    <span>Blog</span>
                </v-btn> -->
            </v-bottom-navigation>
        </v-main>
        <router-view />
        <v-footer :padless="true">
            <v-card flat tile width="100%" class="secondary white--text text-center">
                <!-- <v-card-text>
                    <v-btn class="mx-4 white--text" icon>
                        <v-icon size="24px">mdi-home</v-icon>
                    </v-btn>
                    <v-btn class="mx-4 white--text" icon>
                        <v-icon size="24px">mdi-email</v-icon>
                    </v-btn>
                    <v-btn class="mx-4 white--text" icon>
                        <v-icon size="24px">mdi-calendar</v-icon>
                    </v-btn>
                    <v-btn class="mx-4 white--text" icon>
                        <v-icon size="24px">mdi-delete</v-icon>
                    </v-btn>
                </v-card-text> -->

                <!-- <v-card-text class="white--text pt-0">
                    Phasellus feugiat arcu sapien, et iaculis ipsum elementum sit amet. Mauris cursus commodo interdum. Praesent ut
                    risus eget metus luctus accumsan id ultrices nunc. Sed at orci sed massa consectetur dignissim a sit amet dui.
                    Duis commodo vitae velit et faucibus. Morbi vehicula lacinia malesuada. Nulla placerat augue vel ipsum ultrices,
                    cursus iaculis dui sollicitudin. Vestibulum eu ipsum vel diam elementum tempor vel ut orci. Orci varius natoque
                    penatibus et magnis dis parturient montes, nascetur ridiculus mus.
                </v-card-text> -->

                <v-divider></v-divider>

                <v-card-text class="white--text"> {{ new Date().getFullYear() }} — <strong>FSW Marketplace</strong> </v-card-text>
            </v-card>
        </v-footer>
    </v-app>
</template>
<script>
import { mapFields } from 'vuex-map-fields';

export default {
    data() {
        return {
            activeBtn: 1,
            loading: false,
            items: [],
            search: null,
            select: null,
            states: [
                {
                    value: '1',
                    text: 'Product1'
                }
            ]
        };
    },
    watch: {
        search(val) {
            console.log(val);
            val && val !== this.select && this.querySelections(val);
        }
    },
    computed: {
        ...mapFields('shop', ['Categories', 'TopFourProducts', 'Products'])
    },
    mounted() {
        this.$store.dispatch('shop/Categories');
        this.$store.dispatch('shop/GetAllProducts');
        // this.$store.dispatch('shop/GetTopFourProducts');
    },
    methods: {
        gotoProfile() {
            this.$router.push('/AuthProfile');
        },
        querySelections(v) {
            this.loading = true;
            setTimeout(() => {
                this.items = this.Products.filter(e => {
                    return (e.productName || '').toLowerCase().indexOf((v || '').toLowerCase()) > -1;
                });
                this.loading = false;
            }, 300);
        },
        selectProduct(productId) {
            // console.log(this.select);
            if (productId) this.$router.push('Product/' + productId + '/home');
        }
    }
};
</script>
