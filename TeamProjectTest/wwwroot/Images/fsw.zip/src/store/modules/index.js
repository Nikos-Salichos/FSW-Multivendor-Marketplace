'use strict'
const requireModule = require.context('.', true, /\.js$/)
const modules = {}
requireModule.keys().forEach((fileName) => {
  if (fileName === './index.js') {
    return
  }
  var moduleName=fileName.replace(/(\.\/|\.js)/g, '')
  modules[moduleName] = requireModule(fileName).default
})

export default modules