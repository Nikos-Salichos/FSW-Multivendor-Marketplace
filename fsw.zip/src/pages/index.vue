<template>
    <div>
        <v-container fluid>
            <v-carousel hide-delimiters>
                <v-carousel-item :src="require('../assets/img/home/slider1.jpg')">
                    <v-row class="fill-height" align="center" justify="center">
                        <div class="display-2 white--text pl-5 pr-5 hidden-sm-only"><strong></strong></div>
                        <br />
                    </v-row>
                </v-carousel-item>
                <v-carousel-item :src="require('../assets/img/home/slider2.jpg')">
                    <v-row class="fill-height" align="center" justify="center">
                        <div class="display-2 white--text pl-5 pr-5 hidden-sm-only"><strong></strong></div>
                        <br />
                    </v-row>
                </v-carousel-item>
                <v-carousel-item :src="require('../assets/img/home/slider3.jpg')">
                    <v-row class="fill-height" align="center" justify="center">
                        <div class="display-2 white--text pl-5 pr-5 hidden-sm-only"><strong></strong></div>
                        <br />
                    </v-row>
                </v-carousel-item>
                <v-carousel-item :src="require('../assets/img/home/slider1.jpg')">
                    <v-row class="fill-height" align="center" justify="center">
                        <div class="display-2 white--text pl-5 pr-5 hidden-sm-only"><strong></strong></div>
                        <br />
                    </v-row>
                </v-carousel-item>
            </v-carousel>
        </v-container>
        <v-container fluid>
            <div class="pl-4 pr-4 row">
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <v-card outlined>
                        <v-img
                            :src="require('../assets/img/home/kinita.jpg')"
                            class="white--text align-center"
                            gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
                            height="300px"
                        >
                            <!-- <h1 class="text-center font-size">Κινητά Τηλέφωνα</h1> -->
                            <div class="text-center mt-2">
                                <v-btn class="white--text caption" href="#/Category/5/Κινητά%20Τηλέφωνα" text
                                    >ΚΙΝΗΤΑ ΤΗΛΕΦΩΝΑ <v-icon class="white--text caption">mdi-arrow-right</v-icon></v-btn
                                >
                            </div>
                        </v-img>
                    </v-card>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <v-card outlined>
                        <v-img
                            :src="require('../assets/img/home/paixnidia.jpg')"
                            class="white--text align-center"
                            gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
                            height="300px"
                        >
                            <!-- <h1 class="text-center font-size">Παιχνίδια</h1> -->
                            <div class="text-center mt-2">
                                <v-btn class="white--text caption" href="#/Category/9/Παιχνίδια" text
                                    >ΠΑΙΧΝΙΔΙΑ <v-icon class="white--text caption">mdi-arrow-right</v-icon></v-btn
                                >
                            </div>
                        </v-img>
                    </v-card>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <v-card outlined>
                        <v-img
                            :src="require('../assets/img/home/deal4.jpg')"
                            class="white--text align-center"
                            gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
                            height="300px"
                        >
                            <!-- <h1 class="text-center font-size"></h1> -->
                            <div class="text-center mt-2">
                                <v-btn class="white--text caption" href="#/Category/8/Παπούτσια" text
                                    >ΠΑΠΟΥΤΣΙΑ <v-icon class="white--text caption">mdi-arrow-right</v-icon></v-btn
                                >
                            </div>
                        </v-img>
                    </v-card>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <v-card outlined>
                        <v-img
                            :src="require('../assets/img/home/laptops.jpg')"
                            class="white--text align-center"
                            gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
                            height="300px"
                        >
                            <!-- <h1 class="text-center font-size">Laptops</h1> -->
                            <div class="text-center mt-2">
                                <v-btn class="white--text caption" href="#/Category/1/Laptops" text
                                    >LAPTOPS <v-icon class="white--text caption">mdi-arrow-right</v-icon></v-btn
                                >
                            </div>
                        </v-img>
                    </v-card>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <v-card outlined>
                        <v-img
                            :src="require('../assets/img/home/laptopcases.png')"
                            class="white--text align-center"
                            gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
                            height="300px"
                        >
                            <!-- <h1 class="text-center font-size">Laptop Cases</h1> -->
                            <div class="text-center mt-2">
                                <v-btn class="white--text caption" href="#/Category/2/Laptop%20Cases" text
                                    >LAPTOP CASES <v-icon class="white--text caption">mdi-arrow-right</v-icon></v-btn
                                >
                            </div>
                        </v-img>
                    </v-card>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <v-card outlined>
                        <v-img
                            :src="require('../assets/img/home/kouzines.jpg')"
                            class="white--text align-center"
                            gradient="to bottom, rgba(0,0,0,.1), rgba(0,0,0,.5)"
                            height="300px"
                        >
                            <!-- <h1 class="text-center font-size">Κουζίνες</h1> -->
                            <div class="text-center mt-2">
                                <v-btn class="white--text caption" href="#/Category/7/Κουζίνες" text
                                    >ΚΟΥΖΙΝΕΣ <v-icon class="white--text caption">mdi-arrow-right</v-icon></v-btn
                                >
                            </div>
                        </v-img>
                    </v-card>
                </div>
            </div>
        </v-container>
        <v-container fluid>
            <v-row no-gutters>
                <v-col :cols="12">
                    <v-card-text class="" tile outlined>
                        <v-card-title class="subheading">Top Products</v-card-title>
                        <v-divider></v-divider>

                        <div class="row">
                            <div
                                class="col-12 col-md-3 col-sm-6 col-xs-6 text-center"
                                v-for="(Product, index) in TopFourProducts"
                                :key="index"
                            >
                                <v-hover v-slot:default="{ hover }" open-delay="200">
                                    <v-card :elevation="hover ? 16 : 2">
                                        <v-img contain class="white--text align-end" height="250px" :src="Product.src">
                                            <v-card-title></v-card-title>
                                        </v-img>

                                        <v-card-text class="text--primary text-center font-weight-medium">
                                            <div>{{ Product.productName }}</div>
                                            <div>{{ Product.price }}€</div>
                                        </v-card-text>

                                        <div class="text-center ">
                                            <v-btn
                                                :to="{
                                                    name: 'Product',
                                                    params: { id: Product.productId, name: Product.productName }
                                                }"
                                                class="ma-2"
                                                outlined
                                                color="info"
                                            >
                                                Explore
                                            </v-btn>
                                        </div>
                                    </v-card>
                                </v-hover>
                            </div>
                        </div>
                    </v-card-text>
                </v-col>
            </v-row>
            <v-card class="accent">
                <v-container>
                    <v-row no-gutters>
                        <v-col class="col-12 col-md-4 col-sm-12">
                            <v-row>
                                <v-col class="col-12 col-sm-3 pr-4" align="right">
                                    <v-icon class="display-2">mdi-truck</v-icon>
                                </v-col>
                                <v-col class="col-12 col-sm-9 pr-4">
                                    <h3 class="font-weight-medium">FREE SHIPPING & RETURN</h3>
                                    <p class="font-weight-medium">Free Shipping over 100€</p>
                                </v-col>
                            </v-row>
                        </v-col>
                        <v-col class="col-12 col-md-4 col-sm-12">
                            <v-row>
                                <v-col class="col-12 col-sm-3 pr-4" align="right">
                                    <v-icon class="display-2">mdi-cash-usd</v-icon>
                                </v-col>
                                <v-col class="col-12 col-sm-9 pr-4">
                                    <h3 class="font-weight-medium">MONEY BACK GUARANTEE</h3>
                                    <p class="font-weight-medium">30 Days Money Back Guarantee</p>
                                </v-col>
                            </v-row>
                        </v-col>
                        <v-col class="col-12 col-md-4 col-sm-12">
                            <v-row>
                                <v-col class="col-12 col-sm-3 pr-4" align="right">
                                    <v-icon class="display-2">mdi-headset</v-icon>
                                </v-col>
                                <v-col class="col-12 col-sm-9 pr-4">
                                    <h3 class="font-weight-medium">210 1234567</h3>
                                    <p class="font-weight-medium">24/7 Available Support</p>
                                </v-col>
                            </v-row>
                        </v-col>
                    </v-row>
                </v-container>
            </v-card>
        </v-container>
    </div>
</template>

<script>
import { mapFields } from 'vuex-map-fields';

export default {
    layout: 'front',
    computed: {
        ...mapFields(['TopFourProducts'])
    },
    data() {
        return {
            items: [{ title: 'Click Me' }, { title: 'Click Me' }, { title: 'Click Me' }, { title: 'Click Me 2' }],
            slides: ['First', 'Second', 'Third', 'Fourth', 'Fifth']
        };
    },
    mounted() {
        this.$store.dispatch('TopFourProducts');
    }
};
</script>
<style>
.v-card--reveal {
    align-items: center;
    bottom: 0;
    justify-content: center;
    opacity: 0.5;
    position: absolute;
    width: 100%;
}

.v-btn__content {
    font-size: 17px;
    font-weight: bold;
}

.mdi-arrow-right::before {
    font-size: 17px;
}
</style>
