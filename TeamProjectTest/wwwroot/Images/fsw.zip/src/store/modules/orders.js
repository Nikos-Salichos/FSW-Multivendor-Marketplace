import api from '@/utils/api1';
import config from '@/config';
import utils from '@/utils';
import { getField, updateField } from 'vuex-map-fields';

const bugout = utils.bugout('test');

var meta = {
    url: config.api.Orders
};
// productName
// price

var state = {
    headers: [
        { text: '', value: 'actions', sortable: false },
        { text: 'Code', value: 'orderCode' },
        { text: 'Product', value: 'productName' },
        { text: 'Price', value: 'price' }
    ],
    rows: [],
    row: {
        subCategoryTypeId: null,
        subCategoryTypeName: null
    }
};

var getters = {
    getField
};

var actions = {
    rows({ commit }) {
        api({
            method: 'get',
            url: meta.url
        }).then(
            function(response) {
                console.log(response.data);
                commit('rows', response.data);
            }.bind(this)
        );
    }
};

var mutations = {
    updateField,
    rows(state, rows) {
        state.rows = rows;
    }
};

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
};
