<template>
    <div>
        <v-container>
            <p class="display-3 font-weight-light	text-center pa-4">SHOPPING CART</p>

            <v-row>
                <v-col :cols="12" md="9" sm="12">
                    <v-simple-table :key="refreshKey">
                        <template v-slot:default>
                            <thead>
                                <tr>
                                    <th class="text-center">ITEM</th>
                                    <th class="">PRICE</th>
                                    <th class="">QUANTITY</th>
                                    <th class="">TOTAL</th>
                                    <th class=""></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(ShoppingItem, index) in ShoppingItems" :key="index">
                                    <td>
                                        <v-list-item key="1" @click="">
                                            <v-list-item-avatar>
                                                <v-img :src="require('../assets/img/shop/1.jpg')"></v-img>
                                            </v-list-item-avatar>

                                            <v-list-item-content>
                                                <v-list-item-title>{{ ShoppingItem.productName }}</v-list-item-title>
                                            </v-list-item-content>
                                        </v-list-item>
                                    </td>
                                    <td>${{ ShoppingItem.amount }}</td>
                                    <td>
                                        <v-text-field
                                            class="pt-10"
                                            label="Outlined"
                                            style="width: 80px;"
                                            single-line
                                            outlined
                                            v-model="ShoppingItem.quantity"
                                            @input="quantityChanged($event, ShoppingItem.productId)"
                                            type="number"
                                        ></v-text-field>
                                    </td>
                                    <td>${{ ShoppingItem.amount }}</td>
                                    <td>
                                        <a><v-icon @click="remove">mdi-cart-off</v-icon></a>
                                    </td>
                                </tr>
                            </tbody>
                        </template>
                    </v-simple-table>
                </v-col>
                <v-col :cols="12" md="3" sm="12" style="background-color: lightgray">
                    <p class="headline">Order Summary</p>
                    <p class="overline">Shipping and additional costs are calculated based on values you have entered.</p>
                    <v-simple-table :key="refreshKey">
                        <template v-slot:default>
                            <tbody>
                                <!-- <tr>
                                    <td>Order Subtotal</td>
                                    <td class="text-right" style="width: 50px;">$160.00</td>
                                </tr>
                                <tr>
                                    <td>Shipping Charges</td>
                                    <td class="text-right" style="width: 50px;">$10.00</td>
                                </tr>
                                <tr>
                                    <td>Tax</td>
                                    <td class="text-right" style="width: 50px;">$5.00</td>
                                </tr> -->
                                <tr>
                                    <td>Total</td>
                                    <td class="text-right" style="width: 50px;">
                                        <b>${{ CartInfo.totalAmount1 }}</b>
                                    </td>
                                </tr>
                            </tbody>
                        </template>
                    </v-simple-table>
                    <div class="text-center" v-show="!paypal">
                        <v-btn class="primary white--text mt-5" @click="proceedToPay" outlined>PROCEED TO PAY</v-btn>
                    </div>
                    <div class="text-center" v-show="paypal" id="paypalContainer" ref="paypalContainer"></div>
                </v-col>
            </v-row>
            -->
        </v-container>

        <v-card class="accent">
            <v-container>
                <v-row no-gutters>
                    <v-col class="col-12 col-md-4 col-sm-12">
                        <v-row>
                            <v-col class="col-12 col-sm-3 pr-4 hidden-sm-only" align="right">
                                <v-icon class="display-2">mdi-truck</v-icon>
                            </v-col>
                            <v-col class="col-12 col-sm-9 pr-4">
                                <h3 class="font-weight-light">FREE SHIPPING & RETURN</h3>
                                <p class="font-weight-thin">Free Shipping over $300</p>
                            </v-col>
                        </v-row>
                    </v-col>
                    <v-col class="col-12 col-md-4 col-sm-12">
                        <v-row>
                            <v-col class="col-12 col-sm-3 pr-4" align="right">
                                <v-icon class="display-2">mdi-cash-usd</v-icon>
                            </v-col>
                            <v-col class="col-12 col-sm-9 pr-4">
                                <h3 class="font-weight-light">MONEY BACK GUARANTEE</h3>
                                <p class="font-weight-thin">30 Days Money Back Guarantee</p>
                            </v-col>
                        </v-row>
                    </v-col>
                    <v-col class="col-12 col-md-4 col-sm-12">
                        <v-row>
                            <v-col class="col-12 col-sm-3 pr-4" align="right">
                                <v-icon class="display-2">mdi-headset</v-icon>
                            </v-col>
                            <v-col class="col-12 col-sm-9 pr-4">
                                <h3 class="font-weight-light">020-800-456-747</h3>
                                <p class="font-weight-thin">24/7 Available Support</p>
                            </v-col>
                        </v-row>
                    </v-col>
                </v-row>
            </v-container>
        </v-card>
    </div>
</template>
<script>
import { mapFields } from 'vuex-map-fields';
import utils from '@/utils';
var PaypalInput = {};
export default {
    layout: 'front',
    // watch: {
    //     ShoppingItems: {
    //         handler(newValue) {
    //             this.refreshKey = Date.now();
    //         },
    //         deep: true
    //     }
    // },
    computed: {
        ...mapFields('shop', ['ShoppingCart', 'Product', 'CartInfo', 'ShoppingItems'])
    },
    mounted() {
        this.refresh();
        this.generateButton();
        this.$on(
            'payment-completed',
            function(response) {
                if (response.status == 'COMPLETED') {
                    this.$store.dispatch('shop/Paid', this.ShoppingCart).then(function(response) {
                        console.log(response);
                    });
                }
            }.bind(this)
        );
    },
    methods: {
        quantityChanged() {
            this.refresh();
            // console.log(arguments);
        },
        remove() {
            console.log(arguments);
        },
        refresh() {
            // this.$store.dispatch('shop/GetShoppingCart');
            console.log(this);
            if (utils.isEmptyObject(this.ShoppingCart)) {
                this.$store.dispatch('shop/CreateShoppingCart').then(
                    function(response) {
                        this.$store.commit('shop/SetShoppingCart', response.data);
                    }.bind(this)
                );
            } else {
                if (!utils.isEmptyObject(this.Product)) {
                    var data = {
                        shoppingCartId: this.ShoppingCart.shoppingCartId,
                        productId: this.Product.productId,
                        quantity: 1,
                        amount: this.Product.price
                    };
                    this.$store.dispatch('shop/CreateShoppingItem', data).then(
                        function(response) {
                            console.log('CreateShoppingItem', response.data);
                            this.refreshKey = Date.now();
                        }.bind(this)
                    );
                }
            }
            this.$store.dispatch('shop/GetCartInfo').then(
                function(response) {
                    this.$store.commit('shop/GetCartInfo', response.data);
                    this.refreshKey = Date.now();
                    this.$store.dispatch('shop/GetShoppingItems').then(
                        function(response) {
                            this.$store.commit('shop/GetShoppingItems', response.data);
                            this.refreshKey = Date.now();
                        }.bind(this)
                    );
                }.bind(this)
            );
            console.log(this.ShoppingCart);
            //
        },
        proceedToPay() {
            console.log(this.CartInfo);
            this.CartInfo.orderCode = Math.floor(Math.random() * 50000) + 10000;
            PaypalInput = {
                custom_id: this.CartInfo.orderCode,
                value: this.CartInfo.totalAmount1
            };
            this.paypal = true;
            this.$emit('payment-completed', { status: 'COMPLETED' });
        },
        paymentCompleted() {},
        generateButton() {
            const paypal = window.paypal;
            const button = Object.assign({
                createOrder: this.createOrder,
                onApprove: this.onApprove
            });
            paypal.Buttons(button).render(this.$refs.paypalContainer);
        },
        createOrder(data, actions) {
            return actions.order.create({
                purchase_units: [
                    {
                        custom_id: PaypalInput.custom_id,
                        amount: {
                            value: PaypalInput.value
                        }
                    }
                ]
            });
        },
        async onApprove(data, actions) {
            const response = await actions.order.capture();
            this.paypal = false;
            console.log(response);
            this.$emit('payment-completed', response);
        }
    },
    data: () => ({
        refreshKey: 0,
        paypal: false,
        orderId: '123',
        amount: 100
    })
};
</script>
