<template>
    <v-data-table
        :headers="headers"
        :items="rows"
        sort-by="subCategoryTypeName"
        class="elevation-1"
        group-by="orderCode"
        style="width: 90%"
        >>
        <template v-slot:top>
            <v-toolbar flat>
                <v-toolbar-title>Orders</v-toolbar-title>
                <v-divider class="mx-4" inset vertical></v-divider>
                <v-spacer></v-spacer>
            </v-toolbar>
        </template>
    </v-data-table>
</template>
<script>
import { mapFields } from 'vuex-map-fields';

var formMeta = {
    title: 'Attribute'
};

export default {
    layout: 'front',
    data: () => ({
        dialog: false,
        dialogDelete: false,
        editedIndex: -1,
        formMode: '',
        editedItem: {
            subCategoryTypeName: ''
        },
        defaultItem: {
            subCategoryTypeName: ''
        }
    }),

    computed: {
        ...mapFields('orders', ['headers', 'rows', 'row'])
    },

    watch: {
        dialog(val) {
            val || this.close();
        },
        dialogDelete(val) {
            val || this.closeDelete();
        }
    },

    mounted() {
        this.$store.dispatch('orders/rows');
        // this.rows = this.$store.getters['attributes/rows'];
    },

    methods: {
        initialize() {},
        form(item) {
            this.formMode = item ? 'Edit' : 'New';
            if (this.formMode == 'Edit') {
                this.row = this.rows.indexOf(item);
                this.row = Object.assign({}, item);
            } else this.row = {};
            this.dialog = true;
        },

        deleteItem(item) {
            // this.editedIndex = this.rows.indexOf(item);
            this.row = Object.assign({}, item);
            this.dialogDelete = true;
        },

        deleteItemConfirm() {
            this.$store.dispatch('attributes/delete', this.row);
            this.closeDelete();
        },

        close() {
            this.dialog = false;
            this.$nextTick(() => {
                this.editedItem = Object.assign({}, this.defaultItem);
                this.editedIndex = -1;
            });
        },

        closeDelete() {
            this.dialogDelete = false;
            this.$nextTick(() => {
                this.editedItem = Object.assign({}, this.defaultItem);
                this.editedIndex = -1;
            });
        },

        save() {
            this.$store.dispatch('attributes/save', this.row);
            this.close();
        }
    }
};
</script>
