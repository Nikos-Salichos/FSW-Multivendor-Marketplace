import _ from 'underscore';
import api from '@/utils/api1';
import config from '@/config';
import utils from '@/utils';
import { getField, updateField } from 'vuex-map-fields';

var state = {
    Categories: [],
    ProductsByCategory: [],
    CategoryStructure: [],
    Product: {},
    Products: [],
    ShoppingCart: {},
    CartInfo: {},
    ShoppingItems: [],
    TopFourProducts: []
};

var getters = {
    getField
};

var actions = {
    GetAllProducts({ commit }) {
        api({
            method: 'get',
            url: config.api.GetAllProducts
        }).then(function(response) {
            console.log('GetAllProducts', response.data);
            commit('GetAllProducts', response.data);
        });
    },
    GetTopFourProducts({ commit }) {
        api({
            method: 'get',
            url: config.api.GetTopFourProducts
        }).then(function(response) {
            console.log('GetTopFourProducts', response.data);
            commit('GetTopFourProducts', response.data);
        });
    },
    Categories({ commit }) {
        api({
            method: 'get',
            url: config.api.Categories
        }).then(function(response) {
            console.log('Categories', response.data);
            commit('Categories', response.data);
        });
    },
    GetByProductId({ commit }, productId) {
        api({
            method: 'get',
            url: config.api.GetByProductId + productId
        }).then(function(response) {
            console.log('GetByProductId', response.data[0]);
            commit('Product', response.data[0]);
        });
    },
    GetProductsByCategoryId({ commit }, categoryId) {
        api({
            method: 'get',
            url: config.api.GetProductsByCategoryId + categoryId
        }).then(function(response) {
            console.log('GetProductsByCategoryId', response.data);
        });
    },
    GetCategoryProductsFilters({ commit }, params) {
        return api({
            method: 'post',
            url: config.api.GetCategoryProducts + '?categoryId=' + params.categoryId + '&SortingId=' + params.SortingId,
            data: params.attrs
        });
    },
    GetCategoryProducts({ commit }, params) {
        api({
            method: 'post',
            url: config.api.GetCategoryProducts + '?categoryId=' + params.categoryId + '&SortingId=' + params.SortingId,
            data: params.attrs
        }).then(function(response) {
            var params = {
                ProductsByCategory: response.data,
                attrs: params.attrs
            };
            commit('ProductsByCategory', params);
        });
    },
    GetCategoryStructure({ commit }, params) {
        api({
            method: 'post',
            url: config.api.GetCategoryStructure + '?categoryId=' + params.categoryId,
            data: params.categoryProducts
        }).then(function(response) {
            var _params = {
                data: response.data,
                attrs: params.attrs
            };
            commit('CategoryStructure', _params);
        });
    },
    CreateShoppingCart({ commit }) {
        return api({
            method: 'post',
            url: config.api.ShoppingCarts,
            data: {}
        });
    },
    CreateShoppingItem({ commit }, params) {
        return api({
            method: 'post',
            url: config.api.ShoppingItems,
            data: params
        });
        //     .then(function (response) {
        //     console.log('CreateShoppingItem', response.data);
        // });
    },
    GetCartInfo({ commit }) {
        return api({
            method: 'get',
            url: config.api.GetCartInfo
        });
        //     .then(function (response) {
        //     console.log('GetCartInfo', response.data);
        //     commit('GetCartInfo', response.data);
        // });
    },
    GetShoppingItems({ commit }) {
        return api({
            method: 'get',
            url: config.api.GetShoppingItems
        });
        //     .then(function (response) {
        //     console.log('GetShoppingItems', response.data);
        //     commit('GetShoppingItems', response.data);
        // });
    },
    Paid({ commit }, params) {
        console.log(params);
        return api({
            method: 'put',
            url: config.api.Paid + params.shoppingCartId,
            data: {
                shoppingCartStateId: 2,
                orderCode: params.orderCode,
                totalAmount: params.totalAmount,
                longitude: params.longitude,
                latitude: params.latitude
            }
        });
        //     .then(function (response) {
        //     console.log('GetShoppingItems', response.data);
        //     commit('GetShoppingItems', response.data);
        // });
    }
};

var mutations = {
    Product(state, Product) {
        Product.src = 'https://localhost:44308/images/' + Product.sku + '.jpeg';
        state.Product = Product;
    },
    Categories(state, Categories) {
        state.Categories = Categories;
    },
    ProductsByCategory(state, params) {
        function commonValues(...arr) {
            let res = arr[0].filter(function(x) {
                return arr.every(y => y.includes(x));
            });
            return res;
        }
        var attrs = params.attrs;
        var ProductsByCategory = params.ProductsByCategory;
        for (var i = 0; i < ProductsByCategory.length; i++) {
            ProductsByCategory[i].src = 'https://localhost:44308/images/' + ProductsByCategory[i].sku + '.jpeg';
        }

        var _attrs = {},
            attributeId,
            productId;
        for (var i = 0; i < ProductsByCategory.length; i++) {
            attributeId = ProductsByCategory[i].attributeId;
            productId = ProductsByCategory[i].productId;
            _attrs[attributeId] = _attrs[attributeId] || [];
            if (_attrs[attributeId].indexOf(productId) == -1) _attrs[attributeId].push(productId);
        }
        _attrs = Object.values(_attrs);
        var result = _attrs.reduce((a, b) => a.filter(c => b.includes(c)));

        var _ProductsByCategory = [];
        for (var i = 0; i < ProductsByCategory.length; i++) {
            if (result.length > 0) {
                if (result.includes(ProductsByCategory[i].productId)) _ProductsByCategory.push(ProductsByCategory[i]);
            }
        }
        if (_ProductsByCategory.length) ProductsByCategory = _ProductsByCategory;

        for (var i = 0; i < ProductsByCategory.length; i++) {
            delete ProductsByCategory[i].attributeId;
            delete ProductsByCategory[i].$id;
        }

        var uniqueProducts = [],
            refProducts = [];
        ProductsByCategory.forEach(function(p) {
            var a = JSON.stringify(p);
            if (uniqueProducts.indexOf(a) === -1) {
                uniqueProducts.push(a);
                refProducts.push(p);
            }
        });
        state.ProductsByCategory = refProducts;
    },
    CategoryStructure(state, params) {
        var CategoryStructure = params.data;
        var rows = utils.clone(CategoryStructure);
        var _CategoryStructure = {};
        rows.forEach(function(r1) {
            _CategoryStructure[r1.subCategoryTypeName] = _CategoryStructure[r1.subCategoryTypeName] || {};
            _CategoryStructure[r1.subCategoryTypeName][r1.attributeValue] =
                _CategoryStructure[r1.subCategoryTypeName][r1.attributeValue] || {};
            _CategoryStructure[r1.subCategoryTypeName][r1.attributeValue] = r1.attributeId;
        });
        var rows = [],
            attrs = [];
        var keys = Object.keys(_CategoryStructure).sort();
        keys.forEach(function(key) {
            attrs = [];
            for (var attr in _CategoryStructure[key]) {
                var value = false;
                var _attrId = _CategoryStructure[key][attr];
                if (params.attrs.indexOf(_attrId) > -1) value = true;
                attrs.push({
                    v: value,
                    id: _CategoryStructure[key][attr],
                    name: attr
                });
            }
            attrs = attrs.sort();
            rows.push({
                name: key,
                attrs: attrs
            });
        });
        state.CategoryStructure = Object.assign({}, rows);
    },
    SetShoppingCart(state, ShoppingCart) {
        state.ShoppingCart = ShoppingCart[0];
    },
    GetCartInfo(state, CartInfo) {
        state.CartInfo = CartInfo[0];
    },
    GetShoppingItems(state, ShoppingItems) {
        state.ShoppingItems = ShoppingItems;
    },
    GetTopFourProducts(state, TopFourProducts) {
        for (var i = 0; i < TopFourProducts.length; i++) {
            TopFourProducts[i].src = 'https://localhost:44308/images/' + TopFourProducts[i].sku + '.jpeg';
        }
        console.log(TopFourProducts);
        state.TopFourProducts = TopFourProducts;
    },
    GetAllProducts(state, Products) {
        state.Products = Products;
    }
};

// export default {
//     layout: 'front',
//     data: () => ({}),
//     computed: {},
//     watch: {},
//     mounted() {
//         // this.$store.dispatch('shop/GetAllProducts');
//         // this.$store.dispatch('shop/GetTopFourProducts');
//         // this.$store.dispatch('shop/Categories');
//         // this.$store.dispatch('shop/GetByProductId', 3);
//     },
//     methods: {}
// };

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
};
