<template>
    <div>
        <v-container fluid>
            <div class="row">
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <v-card outlined>
                        <v-card-title>Filters</v-card-title>
                        <div v-for="(CatStr, index) in CategoryStructure" :key="index">
                            <v-card-title class="pb-0">{{ CatStr.name }}</v-card-title>
                            <v-container class="pt-0" fluid v-for="(Attr, index) in CatStr.attrs" :key="index">
                                <v-checkbox v-model="Attr.v" :label="Attr.name" hide-details @change="setAttr" dense></v-checkbox>
                            </v-container>
                        </div>
                        <div class="text-center mt-12">
                            <v-btn small color="primary" outlined @click="resetFilters"> Reset Filters </v-btn>
                        </div>
                        <!-- <div>
                            <v-card-title class="pb-0">Customer Rating</v-card-title>
                            <v-container class="pt-0" fluid>
                                <v-checkbox append-icon="mdi-star" label="4 & above" hide-details dense></v-checkbox>
                                <v-checkbox append-icon="mdi-star" label="3 & above" hide-details dense></v-checkbox>
                                <v-checkbox append-icon="mdi-star" label="2 & above" hide-details dense></v-checkbox>
                                <v-checkbox append-icon="mdi-star" label="1 & above" hide-details dense></v-checkbox>
                            </v-container>
                        </div> -->
                    </v-card>
                </div>
                <div class="col-md-9 col-sm-9 col-xs-12">
                    <v-row dense>
                        <v-col cols="12" sm="8" class="pl-6 pt-6">
                            <v-card-title class="subheading">{{ categoryName }}</v-card-title>
                        </v-col>
                        <v-col cols="12" sm="4">
                            <v-select
                                class="pa-0"
                                v-model="select"
                                :items="options"
                                style="margin-bottom: -20px"
                                outlined
                                dense
                            ></v-select>
                        </v-col>
                    </v-row>

                    <v-divider></v-divider>

                    <div class="row text-center">
                        <div class="col-md-3 col-sm-6 col-xs-12" :key="pro.id" v-for="pro in ProductsByCategory">
                            <v-hover v-slot:default="{ hover }">
                                <v-card class="mx-auto" color="grey lighten-4" max-width="600">
                                    <v-img  class="white--text align-end" contain :aspect-ratio="16 / 9" height="200px"  :src="pro.src">
                                        <!-- <v-card-title>{{ pro.productName }} </v-card-title> -->
                                        <v-expand-transition>
                                            <div
                                                v-if="hover"
                                                class="d-flex transition-fast-in-fast-out white darken-2 v-card--reveal display-3 white--text"
                                                style="height: 100%"
                                            >
                                                <v-btn
                                                    v-if="hover"
                                                    :to="{ name: 'Product', params: { id: pro.productId, name: pro.productName } }"
                                                    class=""
                                                    outlined
                                                    >VIEW</v-btn
                                                >
                                            </div>
                                        </v-expand-transition>
                                    </v-img>
                                    <v-card-text class="text--primary">
                                        <div>
                                            <a href="#" style="text-decoration: none">{{ pro.productName }}</a>
                                        </div>
                                        <div>${{ pro.price }}</div>
                                    </v-card-text>
                                </v-card>
                            </v-hover>
                        </div>
                    </div>
                </div>
            </div>
        </v-container>
    </div>
</template>
<style>
.v-card--reveal {
    align-items: center;
    bottom: 0;
    justify-content: center;
    opacity: 0.8;
    position: absolute;
    width: 100%;
}
</style>
<script>
import { mapFields } from 'vuex-map-fields';
import utils from '@/utils';

export default {
    layout: 'front',
    computed: {
        ...mapFields('shop', ['ProductsByCategory', 'CategoryStructure']),
    },
    watch: {
        $route(to, from) {
            this.categoryName = to.params.name;
            this.categoryId = to.params.id;
            this.refresh([], true);
        },
    },
    mounted() {
        this.categoryId = this.$route.params.id;
        this.refresh([], true);
    },
    methods: {
        refresh(attrs, withFilters) {
            attrs = attrs || [];
            var categoryId = this.categoryId;
            var params = {
                categoryId: categoryId,
                SortingId: 0,
                attrs: attrs,
            };
            var categoryProducts = this.ProductsByCategory.map(function (p) {
                return p.productId;
            });
            console.log(categoryProducts);
            this.$store.dispatch('shop/GetCategoryProducts', params);
            console.log(this);

            // if (withFilters)
            var GetCategoryStructureParams = {
                categoryId: categoryId,
                categoryProducts: categoryProducts,
                attrs: attrs,
            };
            this.$store.dispatch('shop/GetCategoryStructure', GetCategoryStructureParams);
            this.categoryName = this.$route.params.name;
        },
        setAttr(e) {
            var attrs = [];
            var CategoryStructure = utils.clone(this.$store.state.shop.CategoryStructure);
            Object.keys(CategoryStructure).forEach(function (key) {
                CategoryStructure[key].attrs.forEach(function (attr) {
                    if (attr.v) attrs.push(attr.id);
                });
            });
            this.refresh(attrs);
        },
        resetFilters() {
            this.refresh([], true);
        },
    },
    data: () => ({
        categoryId: null,
        categoryName: '',
        select: 'Popularity',
        options: ['Default', 'Popularity', 'Relevance', 'Price: Low to High', 'Price: High to Low'],
        page: 1,
    }),
};
</script>
