import { Debugout } from 'debugout.js';
// const bugout = utils.bugout('bugout');
// bugout.log(response.data);

function arrayFromObject(obj) {
    var arr = [];
    for (var i in obj) {
        arr.push(obj[i]);
    }
    return arr;
}

function groupBy(list, fn) {
    var groups = {};
    for (var i = 0; i < list.length; i++) {
        var group = JSON.stringify(fn(list[i]));
        if (group in groups) {
            groups[group].push(list[i]);
        } else {
            groups[group] = [list[i]];
        }
    }
    console.log(groups);
    return arrayFromObject(groups);
}

export default {
    bugout: function(logFilename) {
        const bugout = new Debugout({ realTimeLoggingOn: true, logFilename: logFilename + '.txt' });
        window.bugout = bugout;
        return bugout;
    },
    sortObj: function(object) {
        if (typeof object != 'object')
            // Not to sort the array
            return object;
        var keys = Object.keys(object);
        keys.sort(function(a, b) {
            if (typeof object[a] !== 'object') {
                return -1;
            } else {
                return 1;
            }
        });
        if (Object.prototype.toString.call(object) === '[object Array]') {
            var newObject = [];
        } else {
            var newObject = {};
        }

        for (var i = 0; i < keys.length; i++) {
            newObject[keys[i]] = this.sortObj(object[keys[i]]);
        }
        return newObject;
    },
    clone: function(obj) {
        return JSON.parse(JSON.stringify(obj));
    },
    log: function(obj, msg) {
        if (msg) console.log(msg, JSON.stringify(obj, null, '\t'));
        else console.log(JSON.stringify(obj));
    },
    isEmptyObject(obj) {
        if (obj && Object.keys(obj).length > 0) return false;
        return true;
    },
    hasLoginToken() {
        return typeof localStorage.loginToken !== 'undefined';
    },
    getSubCategories(data) {
        var subCategs = {},
            SubCategories = [];
        data.data.forEach(function(sub) {
            subCategs[sub.subCategoryTypeName] = subCategs[sub.subCategoryTypeName] || {};
            subCategs[sub.subCategoryTypeName][sub.attributeValue] = sub.attributeId;
        });
        var all = Object.keys(subCategs).sort();
        all.forEach(function(sb) {
            var types = [];
            var subTypes = Object.keys(subCategs[sb]).sort();
            subTypes.forEach(function(sbt) {
                types.push({
                    value: subCategs[sb][sbt],
                    text: sbt
                });
            });
            SubCategories.push({
                value: subCategs[sb],
                text: sb,
                selected: null,
                types: types
            });
        });
        return SubCategories;
    }
};
