import api from '@/utils/api1';
import config from '@/config';
import utils from '@/utils';
import { getField, updateField } from 'vuex-map-fields';

const bugout = utils.bugout('test');

var meta = {
    url: config.api.SubCategoryTypes
};

var state = {
    headers: [
        { text: '', value: 'actions', sortable: false },
        { text: 'Attribute Name', value: 'subCategoryTypeName' }
    ],
    rows: [],
    row: {
        subCategoryTypeId: null,
        subCategoryTypeName: null
    }
};

var getters = {
    getField
};

var actions = {
    rows({ commit }) {
        api({
            method: 'get',
            url: meta.url
        }).then(
            function(response) {
                commit('rows', response.data);
            }.bind(this)
        );
    },
    save({ dispatch }, data) {
        var action = data.subCategoryTypeId ? 'update' : 'insert';
        if (action == 'update') {
            api({
                method: 'put',
                url: meta.url + data.subCategoryTypeId,
                data: {
                    subCategoryTypeId: data.subCategoryTypeId,
                    subCategoryTypeName: data.subCategoryTypeName
                }
            }).then(function(response) {
                dispatch('rows');
            });
        } else if (action == 'insert') {
            api({
                method: 'post',
                url: meta.url,
                data: {
                    subCategoryTypeName: data.subCategoryTypeName
                }
            }).then(function(response) {
                dispatch('rows');
            });
        }
    },
    delete({ dispatch }, data) {
        api({
            method: 'delete',
            url: meta.url + data.subCategoryTypeId,
            data: {
                subCategoryTypeName: data.subCategoryTypeName
            }
        }).then(function(response) {
            dispatch('rows');
        });
    }
};

var mutations = {
    updateField,
    rows(state, rows) {
        state.rows = rows;
    }
};

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
};
