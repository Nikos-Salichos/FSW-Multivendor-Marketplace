<template>
    <v-main>
        <v-container fill-height fluid>
            <v-layout align-center justify-center>
                <v-flex xs12 sm8 md8>
                    <v-card class="elevation-12">
                        <v-toolbar color="general">
                            <v-toolbar-title>Market Place Reset Password</v-toolbar-title>
                            <v-spacer />
                        </v-toolbar>
                        <v-card-text>
                            <v-form>
                                <!-- <v-select v-model="role" :items="roles" label="Role" prepend-icon="mdi-account-multiple"></v-select> -->
                                <v-text-field
                                    ref="password"
                                    v-model="password"
                                    :rules="[() => !!password || 'This field is required']"
                                    :append-icon="showPassword ? 'mdi-eye-off' : 'mdi-eye'"
                                    :type="showPassword ? 'text' : 'password'"
                                    prepend-icon="mdi-lock"
                                    label="Old Password"
                                    placeholder="*********"
                                    counter
                                    required
                                    @keydown.enter="login"
                                    @click:append="showPassword = !showPassword"
                                />
                                <v-text-field
                                    ref="password"
                                    v-model="password"
                                    :rules="[() => !!password || 'This field is required']"
                                    :append-icon="showPassword ? 'mdi-eye-off' : 'mdi-eye'"
                                    :type="showPassword ? 'text' : 'password'"
                                    prepend-icon="mdi-lock"
                                    label="New Password"
                                    placeholder="*********"
                                    counter
                                    required
                                    @keydown.enter="login"
                                    @click:append="showPassword = !showPassword"
                                />
                                <v-text-field
                                    ref="password"
                                    v-model="password"
                                    :rules="[() => !!password || 'This field is required']"
                                    :append-icon="showPassword ? 'mdi-eye-off' : 'mdi-eye'"
                                    :type="showPassword ? 'text' : 'password'"
                                    prepend-icon="mdi-lock"
                                    label="New Password"
                                    placeholder="*********"
                                    counter
                                    required
                                    @keydown.enter="login"
                                    @click:append="showPassword = !showPassword"
                                />
                            </v-form>
                        </v-card-text>
                        <v-divider class="mt-5" />
                        <v-card-actions>
                            <v-spacer />
                            <v-btn align-center justify-center color="general" @click="resetPassword">Reset password </v-btn>
                        </v-card-actions>
                        <v-snackbar v-model="snackbar" :color="color" :top="true">
                            {{ errorMessages }}
                            <v-btn dark @click="snackbar = false"> Close </v-btn>
                        </v-snackbar>
                    </v-card>
                </v-flex>
            </v-layout>
        </v-container>
    </v-main>
</template>

<script>
export default {
    layout: 'simple',
    data: function () {
        return {
            roles: ['Admin', 'Vendor'],
            username: 'Plaisio',
            password: 'Plaisio$123$',
            // role: '',
            errorMessages: 'Incorrect login info',
            snackbar: false,
            color: 'general',
            showPassword: false,
        };
    },

    // Sends action to Vuex that will log you in and redirect to the dash otherwise, error
    methods: {
        resetPassword: function () {
            let username = this.username;
            let password = this.password;
            // let role = this.role;
            this.$router.push('/login');
            this.$store.dispatch('user/resetPassword', { username, password })
                // .then(
                //     function () {
                //         this.$router.push('/login');
                //     }.bind(this)
                // )
                // .catch((err) => {
                //     this.errorMessages = err;
                //     this.snackbar = true;
                // });
        },
    },
};
</script>
