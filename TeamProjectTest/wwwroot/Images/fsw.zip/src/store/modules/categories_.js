import axios from 'axios';
import utils from '@/utils';

const bugout = utils.bugout('test');

var state = {
    headers: [
        { text: '', value: 'actions', sortable: false },
        { text: 'Category', value: 'categoryName' }
    ],
    rows: [],
    row: {
        categoryId: null,
        categoryName: null
    },
    selectedSubs: []
};

var getters = {
    rows(state) {
        return state.rows;
    },
    selectedSubs(state) {
        return state.selectedSubs;
    }
};

var actions = {
    rows({ commit }) {
        axios.get('https://localhost:44308/api/Categories').then(
            function(response) {
                bugout.log(response.data);
                commit('rows', response.data);
            }.bind(this)
        );
    },
    save({ commit }, data) {
        var action = data.categoryId ? 'update' : 'insert';
        if (action == 'update') {
            return new Promise((resolve, reject) => {
                axios({
                    method: 'put',
                    url: 'https://localhost:44308/api/Categories?id=' + data.categoryId,
                    data: {
                        categoryId: data.categoryId,
                        categoryName: data.categoryName
                    }
                })
                    .then(function(response) {
                        console.log(response.data);
                        resolve(true);
                    })
                    .catch(error => {
                        var errorMessage = 'Generic Error';
                        if (error.response) {
                            errorMessage = error.response.data;
                        } else if (error.request) {
                            // The request was made but no response was received
                            console.log(error.request);
                        } else {
                            // Something happened in setting up the request that triggered an Error
                            console.log('Error', error.message);
                        }
                        console.log(errorMessage);
                        reject(errorMessage);
                    });
            });
        } else {
            return new Promise((resolve, reject) => {
                axios({
                    method: 'post',
                    url: 'https://localhost:44308/api/Categories',
                    data: {
                        categoryName: data.categoryName
                    }
                })
                    .then(function(response) {
                        console.log(response.data);
                        resolve(true);
                    })
                    .catch(error => {
                        var errorMessage = 'Generic Error';
                        if (error.response) {
                            // errorMessage = error.response.data;
                        } else if (error.request) {
                            // The request was made but no response was received
                            console.log(error.request);
                        } else {
                            // Something happened in setting up the request that triggered an Error
                            console.log('Error', error.message);
                        }
                        console.log(errorMessage);
                        reject(errorMessage);
                    });
            });
        }
    }
};
var mutations = {
    rows(state, rows) {
        state.rows = rows;
    }
};

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
};
