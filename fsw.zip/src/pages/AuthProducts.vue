<template>
    <v-data-table :headers="headers" :items="rows" sort-by="price" class="elevation-1" style="width: 90%"
        >>
        <template v-slot:top>
            <v-toolbar flat>
                <v-toolbar-title>Products</v-toolbar-title>
                <v-divider class="mx-4" inset vertical></v-divider>
                <v-spacer></v-spacer>
                <v-dialog v-model="dialog" max-width="70%">
                    <template v-slot:activator="{ on, attrs }">
                        <v-btn color="primary" dark class="mb-2" @click="form()"> New Product</v-btn>
                    </template>
                    <v-card>
                        <v-card-title>
                            <span class="headline">{{ formTitle }}</span>
                        </v-card-title>
                        <!--Auto einai to pinakaki gia to edit kai to insert -->
                        <v-card-text>
                            <v-container>
                                <v-row dense>
                                    <v-col cols="12" sm="6" md="6">
                                        <v-text-field hide-details v-model="row.productName" label="Product"></v-text-field>
                                    </v-col>
                                    <v-col cols="12" sm="6" md="6">
                                        <v-text-field hide-details v-model="row.price" label="Price"> </v-text-field>
                                    </v-col>
                                    <v-col cols="12" sm="6" md="6">
                                        <v-text-field hide-details v-model="row.sku" label="SKU"></v-text-field>
                                    </v-col>
                                    <v-col cols="12" sm="6" md="6">
                                        <v-file-input
                                            v-model="row.chosenFile"
                                            label="Image"
                                            prepend-icon="mdi-camera"
                                        ></v-file-input>
                                    </v-col>
                                    <!-- <v-col cols="12" sm="6" md="4">
                                        <v-select
                                            v-model="row.productStatus"
                                            :items="productStatuses"
                                            label="Status"
                                            item-text="text"
                                            item-value="value"
                                        ></v-select>
                                    </v-col> -->
                                    <v-col cols="12" sm="6" md="12">
                                        <v-textarea
                                            label="Description"
                                            v-model="row.description"
                                            rows="2"
                                            auto-grow
                                            hide-details
                                        ></v-textarea>
                                    </v-col>
                                    <v-col cols="12" sm="6" md="12">
                                        <v-select
                                            v-model="row.categoryId"
                                            :items="Categories"
                                            label="Category"
                                            item-text="categoryName"
                                            item-value="categoryId"
                                        ></v-select>
                                    </v-col>
                                </v-row>
                            </v-container>
                            <v-container v-for="(SubCategory, index) in SubCategories" :key="index" v-show="formMode=='Edit'">
                                <div>
                                    <span class="v-list-item__title">{{ SubCategory.text }}</span>
                                </div>
                                <v-radio-group v-model="SubCategory.selected">
                                    <v-radio
                                        v-for="SubCategoryType in SubCategory.types"
                                        :key="SubCategoryType.value"
                                        :label="SubCategoryType.text"
                                        :value="SubCategoryType.value"
                                    ></v-radio>
                                </v-radio-group>
                            </v-container>
                        </v-card-text>

                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn color="blue darken-1" text @click="close"> Cancel </v-btn>
                            <v-btn color="blue darken-1" text @click="save"> Save </v-btn>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
                <v-dialog v-model="dialogDelete" max-width="500px">
                    <v-card>
                        <v-card-title class="headline">Are you sure you want to delete this item?</v-card-title>
                        <v-card-actions>
                            <v-spacer></v-spacer>
                            <v-btn color="blue darken-1" text @click="closeDelete">Cancel</v-btn>
                            <v-btn color="blue darken-1" text @click="deleteItemConfirm">OK</v-btn>
                            <v-spacer></v-spacer>
                        </v-card-actions>
                    </v-card>
                </v-dialog>
            </v-toolbar>
        </template>
        <template v-slot:item.actions="{ item }">
            <!-- v-slot:item.actions="{ item }" -->
            <v-icon small class="mr-2" @click="form(item)"> mdi-pencil </v-icon>
            <v-icon small @click="deleteItem(item)">
                mdi-delete
            </v-icon>
        </template>
    </v-data-table>
</template>
<script>
// v-show="formMode == 'New'"
import { mapFields } from 'vuex-map-fields';
import utils from '@/utils';
var formMeta = {
    title: 'Product',
    storeModule: 'products'
};
var file = null;
export default {
    data: () => ({
        dialog: false,
        dialogDelete: false,
        editedIndex: -1,
        formMode: 'New',
        editedItem: {
            productName: '',
            sku: 0,
            price: 0,
            rating: 0,
            productStatus: 0,
            chosenFile: null
        },
        defaultItem: {
            productName: '',
            sku: 0,
            price: 0,
            rating: 0,
            productStatus: 0,
            chosenFile: null
        },
        SubCategories: [],
        productAttributes: []
    }),

    computed: {
        formTitle() {
            return this.formMode + ' ' + formMeta.title;
        },
        ...mapFields(formMeta.storeModule, ['headers', 'rows', 'row', 'productStatuses']),
        Categories() {
            return this.$store.state.Categories;
        }
    },

    watch: {
        dialog(val) {
            val || this.close();
        },
        dialogDelete(val) {
            val || this.closeDelete();
        }
    },

    mounted() {
        this.$store.dispatch(formMeta.storeModule + '/rows');
        this.rows = this.$store.getters[formMeta.storeModule + '/rows'];
        this.$store.dispatch('Categories');
    },

    methods: {
        form(item) {
            this.formMode = item ? 'Edit' : 'New';
            if (this.formMode == 'Edit') {
                this.$store.dispatch('products/GetByProductId', item.productId);
                this.$store.dispatch('products/GetByProductIdForm', item.productId).then(
                    function(response) {
                        var params = {
                            categoryId: response.data[0].categoryId,
                            categoryProducts: []
                            // categoryProducts: [item.productId]
                        };
                        this.$store.dispatch('products/ProductGetCategoryStructure', params).then(
                            function(cs) {
                                this.SubCategories = utils.getSubCategories(cs);
                                console.log(this);
                            }.bind(this)
                        );
                        // commit('row', response.data[0]);
                    }.bind(this)
                );

                // this.$store.dispatch('products/ProductGetCategoryStructure');
                // console.log(Object.keys(this.row));
            } else this.row = {};
            this.dialog = true;
        },

        deleteItem(item) {
            // this.editedIndex = this.rows.indexOf(item);
            this.row = Object.assign({}, item);
            this.dialogDelete = true;
        },

        deleteItemConfirm() {
            this.$store.dispatch(formMeta.storeModule + '/delete', this.row);
            this.closeDelete();
        },

        close() {
            this.dialog = false;
            this.$nextTick(() => {
                this.editedItem = Object.assign({}, this.defaultItem);
                this.editedIndex = -1;
            });
        },

        closeDelete() {
            this.dialogDelete = false;
            this.$nextTick(() => {
                this.editedItem = Object.assign({}, this.defaultItem);
                this.editedIndex = -1;
            });
        },

        save() {
            this.$store.dispatch(formMeta.storeModule + '/save', this.row).then(
                function(response) {
                    this.$store.dispatch(formMeta.storeModule + '/rows');
                    this.setProductAttributes(this.row.productId);
                }.bind(this)
            );
            this.close();
        },
        setProductAttributes() {
            var attrs = this.SubCategories.filter(function(a) {
                if (a.selected) return a.selected;
            }).map(function(a) {
                return a.selected;
            });
            // TODO promises all
            attrs.forEach(
                function(attr) {
                    var params = {
                        productId: this.row.productId,
                        attributeId: attr
                    };
                    this.$store.dispatch(formMeta.storeModule + '/ProductAttributes', params);
                }.bind(this)
            );
        }
    }
};
</script>
