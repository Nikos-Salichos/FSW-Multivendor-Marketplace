import Vue from 'vue';
import VueRouter from 'vue-router';
import store from '@/store';
import routes from './_routes';
import { createRouterLayout } from 'vue-router-layout';
import NotFound from '@/components/base/404.vue';
import utils from '@/utils';
import VueAnalytics from 'vue-analytics';

Vue.use(VueRouter);

const RouterLayout = createRouterLayout(layout => {
    return import('@/layouts/' + layout + '.vue');
});

routes.push({ path: '*', component: NotFound });

const originalPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location) {
    return originalPush.call(this, location).catch(err => err);
};

var router = new VueRouter({
    routes: [
        {
            path: '/',
            component: RouterLayout,
            children: routes
        }
    ]
});

router.beforeEach(function(to, from, next) {
    var requiresAuth = to.path.substr(0, 5) == '/Auth' ? true : false;
    // if (utils.hasLoginToken()) {

    // }

    if (requiresAuth) {
        // if (store.state.User.authorized) {
        if (utils.hasLoginToken()) {
            if (!store.state.User);
            store.state.User.authorized = true;
            next();
        } else {
            next('Login');
        }
    } else {
        next();
    }
});

router.beforeResolve((to, from, next) => {
    // if (to.path) {
    //   NProgress.start();
    // }
    next();
});

router.afterEach(() => {
    // NProgress.done();
});

export default router;
