import api from '@/utils/api1';
import config from '@/config';
import utils from '@/utils';
import { getField, updateField } from 'vuex-map-fields';

var meta = {
    url: config.api.SubCategoryTypes
};
var state = {
    headers: [
        { text: '', value: 'actions', sortable: false },
        { text: 'Product', value: 'productName' },
        { text: 'SKU', value: 'sku' },
        { text: 'Price', value: 'price' },
        { text: 'Rating', value: 'rating' }
    ],
    rows: [],
    row: {
        productId: null,
        productName: null,
        sku: null,
        price: null,
        productStatus: null,
        rating: null,
    }
};

var getters = {
    getField
};

var actions = {
    rows({ commit }) {
        api({
            method: 'get',
            url: config.api.GetAllProducts
        }).then(
            function(response) {
                commit('rows', response.data);
            }.bind(this)
        );
    },
    save({ commit }, data) {
        var action = data.productId ? 'update' : 'insert';
        if (action == 'update') {
            return new Promise((resolve, reject) => {
                console.log(data);
                const formData = new FormData();
                formData.append('ProductId', data.productId);
                formData.append('ProductName', data.productName);
                formData.append('Sku', data.sku);
                formData.append('Image', data.chosenFile);

                axios({
                    method: 'put',
                    url: config.api.UpdateProductById + data.productId,
                    data: formData,
                    headers: { 'Content-Type': 'multipart/form-data' }
                })
                    .then(function(response) {
                        resolve(true);
                    })
                    .catch(function(response) {
                        resolve(false);
                    });

                // axios
                //     .put(
                //         config.api.UpdateProductById + data.productId,
                //         {
                //             ProductId: data.productId,
                //             ProductName: data.productName,
                //             Sku: data.sku
                //             // price: data.price,
                //             // rating: data.rating
                //         },
                //         {
                //             headers: {
                //                 'Content-Type': 'multipart/form-data'
                //             }
                //         }
                //     )
                //     .then(function(response) {
                //         console.log(response.data);
                //         resolve(true);
                //     })
                //     .catch(error => {
                //         var errorMessage = 'Generic Error';
                //         if (error.response) {
                //             errorMessage = error.response.data;
                //         } else if (error.request) {
                //             //     The request was made but no response was received
                //             console.log(error.request);
                //         } else {
                //             //     Something happened in setting up the request that triggered an Error
                //             console.log('Error', error.message);
                //         }
                //         console.log(errorMessage);
                //         reject(errorMessage);
                //     });

                // axios({
                //     method: 'put',
                //     url: config.api.UpdateProductById + data.productId,
                //     data: {
                //         ProductId: data.productId,
                //         ProductName: data.productName,
                //         Sku: data.sku
                //         // price: data.price,
                //         // rating: data.rating
                //     }
                // })
                //     .then(function(response) {
                //         console.log(response.data);
                //         resolve(true);
                //     })
                //     .catch(error => {
                //         var errorMessage = 'Generic Error';
                //         if (error.response) {
                //             errorMessage = error.response.data;
                //         } else if (error.request) {
                //             //     The request was made but no response was received
                //             console.log(error.request);
                //         } else {
                //             //     Something happened in setting up the request that triggered an Error
                //             console.log('Error', error.message);
                //         }
                //         console.log(errorMessage);
                //         reject(errorMessage);
                //     });
            });
        } else {
            return new Promise((resolve, reject) => {
                axios({
                    method: 'post',
                    url: 'https://localhost:44308/api/Products',
                    data: {
                        productName: data.ProductName,
                        sku: data.Sku,
                        price: data.Price,
                        rating: data.Rating,
                        image: data.Image
                    }
                })
                    .then(function(response) {
                        console.log(response.data);
                        resolve(true);
                    })
                    .catch(error => {
                        var errorMessage = 'Generic Error';
                        if (error.response) {
                            errorMessage = error.response.data;
                        } else if (error.request) {
                            //    The request was made but no response was received
                            console.log(error.request);
                        } else {
                            //   Something happened in setting up the request that triggered an Error
                            console.log('Error', error.message);
                        }
                        console.log(errorMessage);
                        reject(errorMessage);
                    });
            });
        }
    }
};

var mutations = {
    updateField,
    rows(state, rows) {
        state.rows = rows;
    }
};

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
};
