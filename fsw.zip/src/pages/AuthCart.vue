<template>
    <div>
        <v-container>
            <p class="display-3 font-weight-light	text-center pa-4">SHOPPING CART</p>

            <v-row>
                <v-col :cols="12" md="9" sm="12">
                    <v-simple-table :key="refreshKey">
                        <template v-slot:default>
                            <thead>
                                <tr>
                                    <th class="text-center">ITEM</th>
                                    <th class="">PRICE</th>
                                    <th class="">QUANTITY</th>
                                    <th class="">TOTAL</th>
                                    <th class=""></th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(ShoppingItem, index) in ShoppingItems" :key="index">
                                    <td>
                                        <v-list-item key="1" @click="">
                                            <v-list-item-avatar>
                                                <v-img :src="require('../assets/img/shop/cart.jpg')"></v-img>
                                            </v-list-item-avatar>

                                            <v-list-item-content>
                                                <v-list-item-title>{{ ShoppingItem.productName }}</v-list-item-title>
                                            </v-list-item-content>
                                        </v-list-item>
                                    </td>
                                    <td>{{ ShoppingItem.amount }}€</td>
                                    <td>
                                        <v-text-field
                                            class="pt-10"
                                            label="Outlined"
                                            style="width: 80px;"
                                            single-line
                                            outlined
                                            v-model="ShoppingItem.quantity"
                                            @input="quantityChanged($event, ShoppingItem)"
                                            type="number"
                                        ></v-text-field>
                                    </td>
                                    <td>{{ ShoppingItem.amount }}€</td>
                                    <td>
                                        <a><v-icon @click="remove(ShoppingItem)">mdi-cart-off</v-icon></a>
                                    </td>
                                </tr>
                            </tbody>
                        </template>
                    </v-simple-table>
                </v-col>
                <v-col :cols="12" md="3" sm="12" style="background-color: lightgray">
                    <p class="headline">Order Summary</p>
                    <p class="overline">Shipping and additional costs are calculated based on values you have entered.</p>
                    <v-simple-table :key="refreshKey">
                        <template v-slot:default>
                            <tbody>
                                <!-- <tr>
                                    <td>Order Subtotal</td>
                                    <td class="text-right" style="width: 50px;">$160.00</td>
                                </tr>
                                <tr>
                                    <td>Shipping Charges</td>
                                    <td class="text-right" style="width: 50px;">$10.00</td>
                                </tr>
                                <tr>
                                    <td>Tax</td>
                                    <td class="text-right" style="width: 50px;">$5.00</td>
                                </tr> -->
                                <tr>
                                    <td>Total</td>
                                    <td class="text-right" style="width: 50px;">
                                        <b>{{ totalAmount }}€</b>
                                    </td>
                                </tr>
                            </tbody>
                        </template>
                    </v-simple-table>
                    <div class="text-center" v-show="!paypal">
                        <v-btn class="primary white--text mt-5" @click="proceedToPay" outlined>PROCEED TO PAY</v-btn>
                    </div>
                    <div class="text-center" v-show="paypal" id="paypalContainer" ref="paypalContainer"></div>
                </v-col>
            </v-row>
        </v-container>
    </div>
</template>
<script>
import { mapFields } from 'vuex-map-fields';
import utils from '@/utils';
var PaypalInput = {};
export default {
    layout: 'front',
    // watch: {
    //     CartInfo: {
    //         handler(newValue) {
    //             console.log(newValue);
    //             // this.refreshKey = Date.now();
    //         },
    //         deep: true
    //     }
    // },
    computed: {
        // ...mapFields('shop', ['ShoppingCart', 'Product']),
        ...mapFields(['ShoppingCart', 'ShoppingItems', 'CartInfo', 'Product']),
        totalAmount() {
            if (this.CartInfo) return this.CartInfo.totalAmount1;
            else return 0;
        }
    },
    mounted() {
        this.refresh();
        this.generateButton();
        this.$on(
            'payment-completed',
            function(response) {
                this.ShoppingCart.orderCode = PaypalInput.custom_id;
                if (response.status == 'COMPLETED') {
                    this.$store.dispatch('Paid', this.ShoppingCart).then(
                        function(response) {
                            this.$router.push('/AuthOrders');
                        }.bind(this)
                    );
                }
            }.bind(this)
        );
    },
    methods: {
        quantityChanged(quantity, ShoppingItem) {
            var data = {
                amount: ShoppingItem.amount * quantity,
                productId: ShoppingItem.productId,
                quantity: quantity,
                shoppingItemId: ShoppingItem.shoppingItemId
            };
            this.$store.dispatch('UpdateShoppingItemQuantity', data).then(
                function(response) {
                    console.log(response);
                    this.refresh();
                }.bind(this)
            );
        },
        remove(ShoppingItem) {
            this.$store.dispatch('DeleteShoppingItem', ShoppingItem).then(
                function(response) {
                    this.refresh();
                }.bind(this)
            );
        },
        refresh() {
            if (this.ShoppingCart.shoppingCartId) {
                this.getCartData();
                console.log(this.ShoppingCart);
            }
        },
        getCartData() {
            this.$store.dispatch('GetCartInfo').then(
                function(response) {
                    this.$store.commit('GetCartInfo', response.data);
                    this.$store.dispatch('GetShoppingItems').then(
                        function(response) {
                            this.$store.commit('ShoppingItems', response.data);
                            if (this.ShoppingItems.length);
                            this.withCardInfo = true;
                        }.bind(this)
                    );
                }.bind(this)
            );
        },
        proceedToPay() {
            this.CartInfo.orderCode = Math.floor(Math.random() * 50000) + 10000;
            PaypalInput = {
                custom_id: this.CartInfo.orderCode,
                value: this.CartInfo.totalAmount1
            };
            this.paypal = true;
        },
        paymentCompleted() {},
        generateButton() {
            const paypal = window.paypal;
            const button = Object.assign({
                createOrder: this.createOrder,
                onApprove: this.onApprove
            });
            paypal.Buttons(button).render(this.$refs.paypalContainer);
        },
        createOrder(data, actions) {
            return actions.order.create({
                purchase_units: [
                    {
                        custom_id: PaypalInput.custom_id,
                        amount: {
                            value: PaypalInput.value
                        }
                    }
                ]
            });
        },
        async onApprove(data, actions) {
            const response = await actions.order.capture();
            this.paypal = false;
            console.log(response);
            this.$emit('payment-completed', response);
        }
    },
    data: () => ({
        refreshKey: 0,
        withCardInfo: false,
        paypal: false,
        orderId: '123',
        amount: 100
    })
};
</script>
