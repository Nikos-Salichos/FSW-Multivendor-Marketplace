import Vue from 'vue';
import Vuex from 'vuex';
import createLogger from 'vuex/dist/logger';
import { getField, updateField } from 'vuex-map-fields';
import api from '@/utils/api1';

import config from '@/config';
import utils from '@/utils';

import modules from './modules';

Vue.use(Vuex);

var state = {
    User: {},
    Categories: [],
    Products: [],
    Product: {},
    TopFourProducts: [],
    ShoppingCart: {},
    CartInfo: {
        totalAmount1: 0
    },
    ShoppingItems: []
};

var getters = {
    getField
};
//
var actions = {
    Login({ commit }, userData) {
        return api({
            method: 'post',
            url: config.api.Login,
            data: {
                username: userData.username,
                password: userData.password
            }
        });
    },
    Logout({ commit }, userData) {
        commit('Logout');
    },
    Register({ commit }, userData) {
        return api({
            method: 'post',
            url: config.api[userData.role + 'Register'],
            data: {
                username: userData.username,
                email: userData.email,
                password: userData.password
            }
        });
    },
    Categories({ commit }) {
        api({
            method: 'get',
            url: config.api.Categories
        }).then(function(response) {
            commit('Categories', response.data);
        });
    },
    Products({ commit }) {
        api({
            method: 'get',
            url: config.api.GetAllProducts
        }).then(function(response) {
            commit('Products', response.data);
        });
    },
    GetByProductId({ commit }, productId) {
        api({
            method: 'get',
            url: config.api.GetByProductId + productId
        }).then(function(response) {
            commit('Product', response.data[0]);
        });
    },
    TopFourProducts({ commit }) {
        api({
            method: 'get',
            url: config.api.GetTopFourProducts
        }).then(function(response) {
            commit('TopFourProducts', response.data);
        });
    },
    CreateShoppingCart({ commit }) {
        return api({
            method: 'post',
            url: config.api.ShoppingCarts,
            data: {}
        });
    },
    GetCartInfo({ commit }) {
        return api({
            method: 'get',
            url: config.api.GetCartInfo
        });
    },
    CreateShoppingItem({ commit }, params) {
        return api({
            method: 'post',
            url: config.api.ShoppingItems,
            data: params
        });
    },
    UpdateShoppingItemQuantity({ commit }, params) {
        return api({
            method: 'put',
            url: config.api.ShoppingItems + '/' + params.shoppingItemId,
            data: params
        });
    },
    DeleteShoppingItem({ commit }, params) {
        return api({
            method: 'delete',
            url: config.api.ShoppingItems + '/' + params.shoppingItemId
            // data: params
        });
    },
    GetShoppingItems({ commit }) {
        return api({
            method: 'get',
            url: config.api.GetShoppingItems
        });
    },
    Paid({ commit }, params) {
        console.log(params);
        return api({
            method: 'put',
            url: config.api.Paid + params.shoppingCartId,
            data: {
                shoppingCartId: params.shoppingCartId,
                shoppingCartStateId: 2,
                orderCode: params.orderCode,
                totalAmount: params.totalAmount || 123,
                longitude: 0,
                latitude: 0
            }
        });
    }
};

var mutations = {
    updateField,
    Login(state, userData) {
        state.User = userData;
    },
    Logout(state) {
        state.User = {
            authorized: false
        };
    },
    Categories(state, Categories) {
        state.Categories = Categories;
    },
    Products(state, Products) {
        state.Products = Products;
    },
    Product(state, Product) {
        Product.src = 'https://localhost:44308/images/' + Product.sku + '.jpeg';
        state.Product = Product;
    },
    GetByProductId({ commit }, productId) {
        api({
            method: 'get',
            url: config.api.GetByProductId + productId
        }).then(function(response) {
            console.log('GetByProductId', response.data[0]);
            commit('Product', response.data[0]);
        });
    },
    TopFourProducts(state, data) {
        for (var i = 0; i < data.length; i++) {
            data[i].src = 'https://localhost:44308/images/' + data[i].sku + '.jpeg';
        }
        state.TopFourProducts = data;
    },
    SetShoppingCart(state, ShoppingCart) {
        state.ShoppingCart = ShoppingCart[0];
    },
    GetCartInfo(state, CartInfo) {
        state.CartInfo = CartInfo[0];
        console.log('GetCartInfo', state.CartInfo);
    },
    ShoppingItems(state, ShoppingItems) {
        state.ShoppingItems = ShoppingItems;
        console.log('ShoppingItems', ShoppingItems);
    }
};

export default new Vuex.Store({
    state: state,
    getters: getters,
    actions: actions,
    mutations: mutations,
    modules: modules
    // plugins: [createLogger()]
});
