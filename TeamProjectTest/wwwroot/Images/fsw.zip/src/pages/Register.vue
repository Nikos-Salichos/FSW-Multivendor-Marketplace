<template>
    <v-main>
        <v-container fill-height fluid>
            <v-layout align-center justify-center>
                <v-flex xs12 sm8 md8>
                    <v-card class="elevation-12">
                        <v-toolbar color="general">
                            <v-toolbar-title>Market Place Register</v-toolbar-title>
                            <v-spacer />
                        </v-toolbar>
                        <v-card-text>
                            <v-form>
                                <v-select v-model="role" :items="roles" label="Role" prepend-icon="mdi-account-multiple"></v-select>
                                <v-text-field
                                    ref="username"
                                    v-model="username"
                                    :rules="[() => !!username || 'This field is required']"
                                    prepend-icon="mdi-account"
                                    label="User Name"
                                    placeholder="TotallyNotThanos"
                                    required
                                />
                                <v-text-field
                                    ref="username"
                                    v-model="email"
                                    :rules="[() => !!username || 'This field is required']"
                                    prepend-icon="mdi-account"
                                    label="Email"
                                    placeholder="TotallyNotThanos"
                                    required
                                />
                                <v-text-field
                                    ref="password"
                                    v-model="password"
                                    :rules="[() => !!password || 'This field is required']"
                                    :append-icon="showPassword ? 'mdi-eye-off' : 'mdi-eye'"
                                    :type="showPassword ? 'text' : 'password'"
                                    prepend-icon="mdi-lock"
                                    label="Password"
                                    placeholder="*********"
                                    counter
                                    required
                                    @keydown.enter="login"
                                    @click:append="showPassword = !showPassword"
                                />
                            </v-form>
                        </v-card-text>
                        <v-divider class="mt-5" />
                        <v-card-actions>
                            <v-spacer />
                            <v-btn align-center justify-center color="general" @click="register">Register </v-btn>
                        </v-card-actions>
                        <v-snackbar v-model="snackbar" :color="color" :top="true">
                            {{ errorMessages }}
                            <v-btn dark @click="snackbar = false"> Close </v-btn>
                        </v-snackbar>
                    </v-card>
                </v-flex>
            </v-layout>
        </v-container>
    </v-main>
</template>

<script>
//   "username": "string",
//   "email": "user@example.com",
//   "password": "string"

export default {
    layout: 'simple',
    data: function() {
        return {
            roles: ['User', 'Vendor'],
            username: '',
            email: '',
            password: '',
            role: '',
            errorMessages: 'Incorrect login info',
            snackbar: false,
            color: 'general',
            showPassword: false
        };
    },

    // Sends action to Vuex that will log you in and redirect to the dash otherwise, error
    methods: {
        register: function() {
            let username = this.username;
            let email = this.email;
            let password = this.password;
            let role = this.role;
            var self = this;
            this.$store.dispatch('user/register', { username, email, password, role }).then(function() {
                self.$router.push('/login');
            });
        }
    }
};
</script>
