import Vue from 'vue';
import VueRouter from 'vue-router';
import store from '@/store';
import routes from './_routes';
import { createRouterLayout } from 'vue-router-layout';
import NotFound from '@/components/base/404.vue';
import VueAnalytics from 'vue-analytics';

Vue.use(VueRouter);

const RouterLayout = createRouterLayout(layout => {
    return import('@/layouts/' + layout + '.vue');
});

routes.push({ path: '*', component: NotFound });

var router = new VueRouter({
    // mode: 'history',
    routes: [
        {
            path: '/',
            component: RouterLayout,
            children: routes
        }
    ]
});

router.beforeEach(function(to, from, next) {
    var requiresAuth = to.path.substr(0, 5) == '/Auth' ? true : false;
    if (requiresAuth) {
        if (store.state.auth.authorized) {
            next();
        } else next('Login');
    } else next();
});

router.beforeResolve((to, from, next) => {
    // if (to.path) {
    //   NProgress.start();
    // }
    next();
});

router.afterEach(() => {
    // NProgress.done();
});

// if (process.env.VUE_APP_GOOGLE_ANALYTICS) {
//     Vue.use(VueAnalytics, {
//         id: process.env.VUE_APP_GOOGLE_ANALYTICS_ID,
//         router,
//         autoTracking: {
//             page: process.env.NODE_ENV !== 'development'
//         }
//     })
// }

export default router;
