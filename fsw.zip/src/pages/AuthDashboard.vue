<template>
    <div class="about">
        <h1>Chart.js</h1>
    </div>
</template>
<script>
export default {};
</script>
