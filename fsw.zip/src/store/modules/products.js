import api from '@/utils/api1';
import config from '@/config';
import utils from '@/utils';
import { getField, updateField } from 'vuex-map-fields';

var state = {
    headers: [
        { text: '', value: 'actions', sortable: false },
        { text: 'Product', value: 'productName' },
        { text: 'SKU', value: 'sku' },
        { text: 'Price', value: 'price' },
        { text: 'Rating', value: 'rating' }
    ],
    rows: [],
    row: {
        productId: null,
        productName: null,
        sku: null,
        price: null,
        productStatus: null,
        rating: null
    },
    productStatuses: [
        {
            value: 1,
            text: 'Active'
        },
        {
            value: 0,
            text: 'Inactive'
        }
    ]
};

var getters = {
    getField
};

var actions = {
    GetByProductId({ commit }, productId) {
        api({
            method: 'get',
            url: config.api.GetByProductId + productId
        }).then(function(response) {
            commit('row', response.data[0]);
        });
    },
    GetByProductIdForm({ commit }, productId) {
        return api({
            method: 'get',
            url: config.api.GetByProductId + productId
        });
    },
    ProductGetCategoryStructure({ commit }, params) {
        return api({
            method: 'post',
            url: config.api.GetCategoryStructure + '?categoryId=' + params.categoryId,
            data: params.categoryProducts
        });
    },
    ProductAttributes({ commit }, params) {
        return api({
            method: 'post',
            url: config.api.ProductAttributes,
            data: {
                productId: params.productId,
                attributeId: params.attributeId
            }
        });
    },
    rows({ commit }) {
        api({
            method: 'get',
            url: config.api.GetAllProducts
        }).then(
            function(response) {
                commit('rows', response.data);
            }.bind(this)
        );
    },
    save({ dispatch }, data) {
        var action = data.productId ? 'update' : 'insert';
        if (action == 'update') {
            var params = {
                ProductId: data.productId,
                ProductName: data.productName,
                Description: data.description,
                Sku: data.sku,
                Price: data.price,
                ProductStatus: 1,
                CategoryId: data.categoryId,
                Rating: 0,
                Image: data.chosenFile
            };
            const formData = new FormData();
            Object.keys(params).forEach(function(fld) {
                formData.append(fld, params[fld]);
            });

            return api({
                method: 'put',
                url: config.api.UpdateProductById + data.productId,
                data: formData,
                headers: { 'Content-Type': 'multipart/form-data' }
            });
            // .then(function (response) {
            //     dispatch('rows');
            // });
        } else if (action == 'insert') {
            var params = {
                ProductName: data.productName,
                Description: data.description,
                Sku: data.sku,
                Price: 123,
                ProductStatus: 1,
                CategoryId: data.categoryId,
                Rating: 0,
                Image: data.chosenFile
            };
            const formData = new FormData();
            Object.keys(params).forEach(function(fld) {
                formData.append(fld, params[fld]);
            });

            return api({
                method: 'post',
                url: config.api.Products,
                data: formData,
                headers: { 'Content-Type': 'multipart/form-data' }
            });
            // .then(function (response) {
            //     dispatch('rows');
            // });
        }
    },
    delete({ dispatch }, data) {
        api({
            method: 'delete',
            url: config.api.DeleteProduct + data.productId
            // data: {
            //     subCategoryTypeName: data.subCategoryTypeName
            // }
        }).then(function(response) {
            dispatch('rows');
        });
    }
};

var mutations = {
    updateField,
    row(state, row) {
        state.row = row;
        console.log(Object.keys(state.row));
    },
    rows(state, rows) {
        state.rows = rows;
    }
};

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
};
