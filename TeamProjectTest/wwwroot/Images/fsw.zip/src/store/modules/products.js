import axios from '@/utils/api';
import config from '@/config';

var state = {
    rows: []
};

var getters = {
    rows(state) {
        return state.rows;
    }
};

var actions = {
    rows({ commit }) {
        axios.get(config.api.GetProductsByVendor).then(
            function(response) {
                commit('rows', response.data);
            }.bind(this)
        );
    },
    save({ commit }, data) {
        var action = data.productId ? 'update' : 'insert';
        if (action == 'update') {
            return new Promise((resolve, reject) => {
                console.log(data);
                const formData = new FormData();
                formData.append('ProductId', data.productId);
                formData.append('ProductName', data.productName);
                formData.append('Sku', data.sku);
                formData.append('Image', data.chosenFile);

                axios({
                    method: 'put',
                    url: config.api.UpdateProductById + data.productId,
                    data: formData,
                    headers: { 'Content-Type': 'multipart/form-data' }
                })
                    .then(function(response) {
                        resolve(true);
                    })
                    .catch(function(response) {
                        resolve(false);
                    });

                // axios
                //     .put(
                //         config.api.UpdateProductById + data.productId,
                //         {
                //             ProductId: data.productId,
                //             ProductName: data.productName,
                //             Sku: data.sku
                //             // price: data.price,
                //             // rating: data.rating
                //         },
                //         {
                //             headers: {
                //                 'Content-Type': 'multipart/form-data'
                //             }
                //         }
                //     )
                //     .then(function(response) {
                //         console.log(response.data);
                //         resolve(true);
                //     })
                //     .catch(error => {
                //         var errorMessage = 'Generic Error';
                //         if (error.response) {
                //             errorMessage = error.response.data;
                //         } else if (error.request) {
                //             //     The request was made but no response was received
                //             console.log(error.request);
                //         } else {
                //             //     Something happened in setting up the request that triggered an Error
                //             console.log('Error', error.message);
                //         }
                //         console.log(errorMessage);
                //         reject(errorMessage);
                //     });

                // axios({
                //     method: 'put',
                //     url: config.api.UpdateProductById + data.productId,
                //     data: {
                //         ProductId: data.productId,
                //         ProductName: data.productName,
                //         Sku: data.sku
                //         // price: data.price,
                //         // rating: data.rating
                //     }
                // })
                //     .then(function(response) {
                //         console.log(response.data);
                //         resolve(true);
                //     })
                //     .catch(error => {
                //         var errorMessage = 'Generic Error';
                //         if (error.response) {
                //             errorMessage = error.response.data;
                //         } else if (error.request) {
                //             //     The request was made but no response was received
                //             console.log(error.request);
                //         } else {
                //             //     Something happened in setting up the request that triggered an Error
                //             console.log('Error', error.message);
                //         }
                //         console.log(errorMessage);
                //         reject(errorMessage);
                //     });
            });
        } else {
            return new Promise((resolve, reject) => {
                axios({
                    method: 'post',
                    url: 'https://localhost:44308/api/Products',
                    data: {
                        productName: data.ProductName,
                        sku: data.Sku,
                        price: data.Price,
                        rating: data.Rating,
                        image: data.Image
                    }
                })
                    .then(function(response) {
                        console.log(response.data);
                        resolve(true);
                    })
                    .catch(error => {
                        var errorMessage = 'Generic Error';
                        if (error.response) {
                            errorMessage = error.response.data;
                        } else if (error.request) {
                            //    The request was made but no response was received
                            console.log(error.request);
                        } else {
                            //   Something happened in setting up the request that triggered an Error
                            console.log('Error', error.message);
                        }
                        console.log(errorMessage);
                        reject(errorMessage);
                    });
            });
        }
    }
};

var mutations = {
    rows(state, rows) {
        state.rows = rows;
        console.log(state.rows);
    }
};

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
};
