<template>
    <div class="hello">
        <h1>(404) Page Not Found</h1>
    </div>
</template>

<script>
export default {};
</script>
