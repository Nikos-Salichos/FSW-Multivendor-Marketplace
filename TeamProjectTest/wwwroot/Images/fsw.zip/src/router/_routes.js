function index() {
    return import(/* webpackChunkName: "index" */ '@/pages/index.vue');
}
function AuthAttrTypes() {
    return import(/* webpackChunkName: "AuthAttrTypes" */ '@/pages/AuthAttrTypes.vue');
}
function AuthCategories() {
    return import(/* webpackChunkName: "AuthCategories" */ '@/pages/AuthCategories.vue');
}
function AuthDashboard() {
    return import(/* webpackChunkName: "AuthDashboard" */ '@/pages/AuthDashboard.vue');
}
function AuthOrders() {
    return import(/* webpackChunkName: "AuthOrders" */ '@/pages/AuthOrders.vue');
}
function AuthProducts() {
    return import(/* webpackChunkName: "AuthProducts" */ '@/pages/AuthProducts.vue');
}
function AuthProfile() {
    return import(/* webpackChunkName: "AuthProfile" */ '@/pages/AuthProfile.vue');
}
function Cart() {
    return import(/* webpackChunkName: "Cart" */ '@/pages/Cart.vue');
}
function Category() {
    return import(/* webpackChunkName: "Category" */ '@/pages/Category.vue');
}
function Login() {
    return import(/* webpackChunkName: "Login" */ '@/pages/Login.vue');
}
function Product() {
    return import(/* webpackChunkName: "Product" */ '@/pages/Product.vue');
}
function Register() {
    return import(/* webpackChunkName: "Register" */ '@/pages/Register.vue');
}
function ResetPassword() {
    return import(/* webpackChunkName: "ResetPassword" */ '@/pages/ResetPassword.vue');
}
function Shop() {
    return import(/* webpackChunkName: "Shop" */ '@/pages/Shop.vue');
}

export default [
    {
        name: 'index',
        path: '',
        component: index
    },
    {
        name: 'AuthAttrTypes',
        path: 'AuthAttrTypes',
        component: AuthAttrTypes
    },
    {
        name: 'AuthCategories',
        path: 'AuthCategories',
        component: AuthCategories
    },
    {
        name: 'AuthDashboard',
        path: 'AuthDashboard',
        component: AuthDashboard
    },
    {
        name: 'AuthOrders',
        path: 'AuthOrders',
        component: AuthOrders
    },
    {
        name: 'AuthProducts',
        path: 'AuthProducts',
        component: AuthProducts
    },
    {
        name: 'AuthProfile',
        path: 'AuthProfile',
        component: AuthProfile
    },
    {
        name: 'Cart',
        path: 'Cart',
        component: Cart
    },
    {
        name: 'Category',
        path: 'Category/:id/:name',
        component: Category
    },
    {
        name: 'Login',
        path: 'Login',
        component: Login
    },
    {
        name: 'Product',
        path: 'Product/:id/:name',
        component: Product
    },
    {
        name: 'Register',
        path: 'Register',
        component: Register
    },
    {
        name: 'ResetPassword',
        path: 'ResetPassword',
        component: ResetPassword
    },
    {
        name: 'Shop',
        path: 'Shop',
        component: Shop
    }
];
