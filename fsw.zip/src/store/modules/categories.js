import api from '@/utils/api1';
import config from '@/config';
import utils from '@/utils';
import { getField, updateField } from 'vuex-map-fields';

const bugout = utils.bugout('test');

var meta = {
    url: config.api.Categories
};

var state = {
    headers: [
        { text: '', value: 'actions', sortable: false },
        { text: 'Category Name', value: 'categoryName' }
    ],
    rows: [],
    row: {
        categoryId: null,
        categoryName: null
    }
};

var getters = {
    getField
};

var actions = {
    rows({ commit }) {
        api({
            method: 'get',
            url: meta.url
        }).then(
            function(response) {
                commit('rows', response.data);
            }.bind(this)
        );
    },
    save({ dispatch }, data) {
        var action = data.categoryId ? 'update' : 'insert';
        if (action == 'update') {
            api({
                method: 'put',
                url: meta.url + data.categoryId,
                data: {
                    categoryId: data.categoryId,
                    categoryName: data.categoryName
                }
            }).then(function(response) {
                dispatch('rows');
            });
        } else if (action == 'insert') {
            api({
                method: 'post',
                url: meta.url,
                data: {
                    categoryName: data.categoryName
                }
            }).then(function(response) {
                dispatch('rows');
            });
        }
    },
    delete({ dispatch }, data) {
        api({
            method: 'delete',
            url: meta.url + data.categoryId,
            data: {
                categoryName: data.categoryName
            }
        }).then(function(response) {
            dispatch('rows');
        });
    }
};

var mutations = {
    updateField,
    rows(state, rows) {
        state.rows = rows;
    }
};

export default {
    namespaced: true,
    state,
    getters,
    actions,
    mutations
};
